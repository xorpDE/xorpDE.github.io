"""Entry point for the in-browser engine (website/js/g25-worker.js, running under Pyodide).

Uses exactly the same pipeline as the command line tool, so a map made on the website is identical to
`python -m g25heatmap make --coords ...` with the same coordinates and settings.
"""
from __future__ import annotations

import json
import re

from . import geo, kriging
from .config import load_settings
from .g25 import CoordinateError, average_samples, parse_coordinates
from .pipeline import MapOptions, generate_map, nearest_populations, reference_set, safe_filename
from .presets import PRESETS, custom_preset, get_preset

_N_SUFFIX = re.compile(r"_\(n=\d+\)$")
kriging.CHUNK_SIZE = 4096  # smaller blocks keep WebAssembly memory low; results are unchanged


def warmup() -> None:
    """Import everything and fill the caches so the first map is quicker."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot  # noqa: F401  (builds the font cache)

    s = load_settings()
    reference_set(s)
    p = get_preset("europe")
    geo.load_rings(str(s.land_geojson))
    if s.basemap == "labels":  # the website uses the plain sea, so labels.py is not shipped there
        from . import labels

        st = s.style()
        labels.label_masks(p.extent, int(round(st.map_height_in * p.extent.aspect * st.dpi)),
                           int(round(st.map_height_in * st.dpi)))


def _none_if_null(value):
    """JavaScript null/undefined (Pyodide JsNull / None) -> None."""
    if value is None or type(value).__name__ in ("JsNull", "JsUndefined"):
        return None
    return value


def render(coords: str, name, max_distance: float, brand: str, region: str = "europe", progress=None,
           view=None):
    """Return (png_bytes or None, json_metadata).  Errors are returned, not raised."""
    name, view, progress = _none_if_null(name), _none_if_null(view), _none_if_null(progress)
    try:
        if progress:
            progress("distances", "Reading your coordinates…", 0.35)
        samples = parse_coordinates(coords or "")
        sample = samples[0] if len(samples) == 1 else average_samples(samples, "Average")
        name = (name or "").strip()
        if name:
            sample.name = name[:80]
        md = float(max_distance or 0.1)
        if not 0.01 <= md <= 1.0:
            raise CoordinateError("the maximum distance must be between 0.01 and 1")
        s = load_settings()
        s.brand = (brand or "").strip()[:80]
        region = region if region in PRESETS else "europe"
        opts = MapOptions(region=region, max_distance=md)
        if view is not None:
            xmin, xmax, ymin, ymax = (float(v) for v in list(view)[:4])
            opts.preset = custom_preset(xmin, xmax, ymin, ymax)
        info: dict = {}
        png = generate_map(sample, None, opts, s, progress=progress, result_info=info)
        nearest = [[_N_SUFFIX.sub("", lab), round(d, 5)] for lab, d in nearest_populations(sample.vector, s, 12)]
        meta = {
            "filename": safe_filename(sample.name) + ("_view" if view is not None else
                                                       ("" if region == "europe" else "_" + region)) + ".png",
            "region": region,
            "view": view is not None,
            "mapBox": info.get("mapBox"),
            "extent": info.get("extent"),
            "title": info.get("title", sample.name),
            "vmin": info.get("vmin"),
            "vmax": info.get("vmax"),
            "nearest": nearest,
            "width": int.from_bytes(png[16:20], "big"),
            "height": int.from_bytes(png[20:24], "big"),
        }
        return png, json.dumps(meta)
    except CoordinateError as exc:
        return None, json.dumps({"error": str(exc), "kind": "input"})
    except Exception as exc:  # report, never crash the worker
        return None, json.dumps({"error": f"{type(exc).__name__}: {exc}", "kind": "internal"})
