"""Spatial interpolation: ordinary kriging (PyKrige-compatible), inverse distance weighting, RBF.

The ordinary kriging here reproduces PyKrige's ``OrdinaryKriging`` (euclidean coordinates,
no anisotropy): same variogram model formulas, same experimental-variogram binning, same
soft-L1 least-squares fit with the same bounds and start values, and the same kriging system
(diagonal of the variogram matrix set to zero, exact values at data points).  Prediction is
vectorised: the weights vector A^-1 [z; 0] is computed once, so a 720 x 720 grid with a few
hundred data points takes well under a second.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import scipy.linalg
from scipy.optimize import least_squares
from scipy.spatial import cKDTree
from scipy.spatial.distance import cdist, pdist

VARIOGRAM_MODELS = ("linear", "power", "gaussian", "spherical", "exponential", "hole-effect")
EPS = 1.0e-10  # same zero cutoff as PyKrige
CHUNK_SIZE = 16384  # grid points per block; lower it to save memory (results do not change)


# --------------------------------------------------------------------------- variogram models
def _linear(m, d):
    return float(m[0]) * d + float(m[1])


def _power(m, d):
    return float(m[0]) * d ** float(m[1]) + float(m[2])


def _gaussian(m, d):
    psill, rng, nugget = float(m[0]), float(m[1]), float(m[2])
    return psill * (1.0 - np.exp(-(d ** 2.0) / (rng * 4.0 / 7.0) ** 2.0)) + nugget


def _exponential(m, d):
    psill, rng, nugget = float(m[0]), float(m[1]), float(m[2])
    return psill * (1.0 - np.exp(-d / (rng / 3.0))) + nugget


def _spherical(m, d):
    psill, rng, nugget = float(m[0]), float(m[1]), float(m[2])
    d = np.asarray(d, dtype=float)
    inside = psill * ((3.0 * d) / (2.0 * rng) - (d ** 3.0) / (2.0 * rng ** 3.0)) + nugget
    return np.where(d <= rng, inside, psill + nugget)


def _hole_effect(m, d):
    psill, rng, nugget = float(m[0]), float(m[1]), float(m[2])
    return psill * (1.0 - (1.0 - d / (rng / 3.0)) * np.exp(-d / (rng / 3.0))) + nugget


_MODEL_FUNCS = {
    "linear": _linear,
    "power": _power,
    "gaussian": _gaussian,
    "spherical": _spherical,
    "exponential": _exponential,
    "hole-effect": _hole_effect,
}


@dataclass
class Variogram:
    """A variogram model with PyKrige's parameter order.

    linear: [slope, nugget]; power: [scale, exponent, nugget];
    gaussian / spherical / exponential / hole-effect: [psill, range, nugget].
    """

    model: str
    params: list = field(default_factory=list)

    def __post_init__(self):
        if self.model not in _MODEL_FUNCS:
            raise ValueError(f"unknown variogram model '{self.model}' (choose from {', '.join(VARIOGRAM_MODELS)})")
        self.params = [float(p) for p in self.params]

    def __call__(self, d):
        return _MODEL_FUNCS[self.model](self.params, np.asarray(d, dtype=float))

    @property
    def nugget(self) -> float:
        return self.params[-1]


def _params_from_user(model: str, params) -> list:
    """User parameters -> internal order, with PyKrige's conventions.

    dict: linear {slope, nugget}; power {scale, exponent, nugget}; others {sill or psill, range, nugget}.
    list: linear [slope, nugget]; power [scale, exponent, nugget]; others [FULL sill, range, nugget].
    """
    if isinstance(params, dict):
        if model == "linear":
            return [params["slope"], params["nugget"]]
        if model == "power":
            return [params["scale"], params["exponent"], params["nugget"]]
        nugget = params["nugget"]
        if "psill" in params:
            psill = params["psill"]
        else:
            psill = params["sill"] - nugget
        return [psill, params["range"], nugget]
    params = [float(p) for p in params]
    expected = 2 if model == "linear" else 3
    if len(params) != expected:
        raise ValueError(f"variogram '{model}' needs {expected} parameters, got {len(params)}")
    if model not in ("linear", "power"):
        sill, rng, nugget = params
        return [sill - nugget, rng, nugget]
    return params


# --------------------------------------------------------------------------- experimental variogram + fit
def experimental_variogram(x, y, z, nlags: int = 6):
    """PyKrige's binning: nlags equal-width bins from the min to the max pair distance."""
    return experimental_variogram_points(np.column_stack([np.asarray(x, float), np.asarray(y, float)]), z, nlags)


def experimental_variogram_points(xy, z, nlags: int = 6):
    """Same as :func:`experimental_variogram` for points of any dimension (an (n, d) array)."""
    xy = np.asarray(xy, float)
    z = np.asarray(z, float)
    d = pdist(xy, metric="euclidean")
    g = 0.5 * pdist(z[:, None], metric="sqeuclidean")
    dmax = np.amax(d)
    dmin = np.amin(d)
    dd = (dmax - dmin) / nlags
    bins = [dmin + n * dd for n in range(nlags)]
    dmax += 0.001
    bins.append(dmax)
    lags = np.full(nlags, np.nan)
    semivariance = np.full(nlags, np.nan)
    for n in range(nlags):
        sel = (d >= bins[n]) & (d < bins[n + 1])
        if np.any(sel):
            lags[n] = np.mean(d[sel])
            semivariance[n] = np.mean(g[sel])
    ok = ~np.isnan(semivariance)
    return lags[ok], semivariance[ok]


def _residuals(params, lags, semivariance, func, weight):
    if weight:
        drange = np.amax(lags) - np.amin(lags)
        k = 2.1972 / (0.1 * drange)
        x0 = 0.7 * drange + np.amin(lags)
        w = 1.0 / (1.0 + np.exp(-k * (x0 - lags)))
        w /= np.sum(w)
        return (func(params, lags) - semivariance) * w
    return func(params, lags) - semivariance


def fit_variogram_to_lags(lags, semivariance, model: str = "linear", weight: bool = False) -> Variogram:
    lags = np.asarray(lags, float)
    sv = np.asarray(semivariance, float)
    if model == "linear":
        x0 = [(np.amax(sv) - np.amin(sv)) / (np.amax(lags) - np.amin(lags)), np.amin(sv)]
        bounds = ([0.0, 0.0], [np.inf, np.amax(sv)])
    elif model == "power":
        x0 = [(np.amax(sv) - np.amin(sv)) / (np.amax(lags) - np.amin(lags)), 1.1, np.amin(sv)]
        bounds = ([0.0, 0.001, 0.0], [np.inf, 1.999, np.amax(sv)])
    else:
        x0 = [np.amax(sv) - np.amin(sv), 0.25 * np.amax(lags), np.amin(sv)]
        bounds = ([0.0, 0.0, 0.0], [10.0 * np.amax(sv), np.amax(lags), np.amax(sv)])
    res = least_squares(_residuals, x0, bounds=bounds, loss="soft_l1",
                        args=(lags, sv, _MODEL_FUNCS[model], weight))
    return Variogram(model, list(res.x))


def fit_variogram(x, y, z, model: str = "linear", nlags: int = 6, weight: bool = False) -> Variogram:
    lags, sv = experimental_variogram(x, y, z, nlags)
    return fit_variogram_to_lags(lags, sv, model, weight)


def fit_variogram_points(points, z, model: str = "linear", nlags: int = 6, weight: bool = False) -> Variogram:
    lags, sv = experimental_variogram_points(points, z, nlags)
    return fit_variogram_to_lags(lags, sv, model, weight)


# --------------------------------------------------------------------------- helpers
def merge_duplicate_locations(x, y, z, tol: float = 0.0):
    """Average values of samples that share a location (within ``tol`` map units)."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    z = np.asarray(z, float)
    if x.size == 0:
        return x, y, z
    if tol > 0:
        xk = np.round(x / tol).astype(np.int64)
        yk = np.round(y / tol).astype(np.int64)
    else:
        xk, yk = x, y
    keys = np.column_stack([xk, yk])
    uniq, inv = np.unique(keys, axis=0, return_inverse=True)
    inv = inv.ravel()
    if len(uniq) == len(x):
        return x, y, z
    cnt = np.bincount(inv)
    return (np.bincount(inv, weights=x) / cnt,
            np.bincount(inv, weights=y) / cnt,
            np.bincount(inv, weights=z) / cnt)


def _pykrige_adjust(xy: np.ndarray, center) -> np.ndarray:
    """PyKrige's anisotropy adjustment with scaling 1 / angle 0: shift to the centre and back.

    Mathematically a no-op, but it changes the last bits of the coordinates; doing exactly the same
    keeps the fitted variogram identical to PyKrige's even for ill-conditioned fits.
    """
    c = np.asarray(center, dtype=float)[None, :]
    a = xy - c
    rot = np.array([[np.cos(-0.0), -np.sin(-0.0)], [np.sin(-0.0), np.cos(-0.0)]])
    stretch = np.array([[1, 0], [0, 1.0]])
    return np.dot(stretch, np.dot(rot, a.T)).T + c


def _grid_points(gx, gy):
    X, Y = np.meshgrid(np.asarray(gx, float), np.asarray(gy, float))
    return np.column_stack([X.ravel(), Y.ravel()])


# --------------------------------------------------------------------------- ordinary kriging
class OrdinaryKriging:
    """Ordinary kriging in euclidean coordinates, numerically matching PyKrige's vectorized backend."""

    def __init__(self, x, y, z, variogram_model: str = "linear", variogram_parameters=None,
                 nlags: int = 6, weight: bool = False, exact_values: bool = True, pseudo_inv: bool = False,
                 coords=None):
        """``coords`` (an (n, d) array, e.g. 3-D points on a sphere) replaces x/y when given."""
        self.z = np.atleast_1d(np.asarray(z, dtype=np.float64)).ravel()
        self.exact_values = bool(exact_values)
        self.pseudo_inv = bool(pseudo_inv)
        if coords is not None:
            pts = np.asarray(coords, dtype=np.float64)
            if pts.ndim != 2 or pts.shape[0] != self.z.size:
                raise ValueError("coords must be an (n, d) array matching z")
            self._center = None
            self._xy = pts
            self.x, self.y = pts[:, 0], pts[:, 1]
        else:
            self.x = np.atleast_1d(np.asarray(x, dtype=np.float64)).ravel()
            self.y = np.atleast_1d(np.asarray(y, dtype=np.float64)).ravel()
            if not (self.x.size == self.y.size == self.z.size):
                raise ValueError("x, y and z must have the same length")
            self._center = ((np.amax(self.x) + np.amin(self.x)) / 2.0, (np.amax(self.y) + np.amin(self.y)) / 2.0)
            self._xy = _pykrige_adjust(np.column_stack([self.x, self.y]), self._center)
        if self.z.size < 2:
            raise ValueError("need at least two data points")
        self.lags, self.semivariance = experimental_variogram_points(self._xy, self.z, nlags)
        if variogram_parameters is not None:
            self.variogram = Variogram(variogram_model, _params_from_user(variogram_model, variogram_parameters))
        else:
            self.variogram = fit_variogram_to_lags(self.lags, self.semivariance, variogram_model, weight)
        n = self.x.size
        a = np.zeros((n + 1, n + 1))
        a[:n, :n] = -self.variogram(cdist(self._xy, self._xy, "euclidean"))
        np.fill_diagonal(a, 0.0)
        a[n, :] = 1.0
        a[:, n] = 1.0
        a[n, n] = 0.0
        self._a = a
        self._a_inv = np.linalg.pinv(a) if self.pseudo_inv else scipy.linalg.inv(a)
        # prediction weights: z_hat = b . (A^-1)^T [z; 0]  -> precompute once
        self._w = self._a_inv.T[:, :n] @ self.z

    @property
    def variogram_model_parameters(self):
        return np.asarray(self.variogram.params)

    def _rhs(self, bd):
        n = self.x.size
        b = np.empty((bd.shape[0], n + 1))
        b[:, :n] = -self.variogram(bd)
        if self.exact_values:
            zero = np.abs(bd) <= EPS
            if np.any(zero):
                b[:, :n][zero] = 0.0
        b[:, n] = 1.0
        return b

    def execute_points(self, px, py, return_variance: bool = False, chunk_size: int | None = None,
                       n_closest_points: int | None = None):
        pts = np.column_stack([np.asarray(px, float).ravel(), np.asarray(py, float).ravel()])
        return self.execute_coords(pts, return_variance, chunk_size, n_closest_points)

    def execute_coords(self, points, return_variance: bool = False, chunk_size: int | None = None,
                       n_closest_points: int | None = None):
        """Predict at an (m, d) array of points in the same coordinate space as the data."""
        chunk_size = int(chunk_size or CHUNK_SIZE)
        pts = np.asarray(points, dtype=float)
        if self._center is not None:
            pts = _pykrige_adjust(pts, self._center)
        if n_closest_points is not None:
            z, ss = self._moving_window(pts, int(n_closest_points), chunk_size)
            return (z, ss) if return_variance else z
        npt = pts.shape[0]
        z = np.empty(npt)
        ss = np.empty(npt) if return_variance else None
        for s in range(0, npt, chunk_size):
            bd = cdist(pts[s:s + chunk_size], self._xy, "euclidean")
            b = self._rhs(bd)
            z[s:s + chunk_size] = b @ self._w
            if return_variance:
                xw = b @ self._a_inv.T
                ss[s:s + chunk_size] = np.sum(xw * -b, axis=1)
        return (z, ss) if return_variance else z

    def execute_grid(self, gx, gy, return_variance: bool = False, chunk_size: int | None = None,
                     n_closest_points: int | None = None):
        gx = np.asarray(gx, float).ravel()
        gy = np.asarray(gy, float).ravel()
        pts = _grid_points(gx, gy)
        out = self.execute_points(pts[:, 0], pts[:, 1], return_variance, chunk_size, n_closest_points)
        if return_variance:
            z, ss = out
            return z.reshape(gy.size, gx.size), ss.reshape(gy.size, gx.size)
        return out.reshape(gy.size, gx.size)

    def _moving_window(self, pts, k, chunk_size):
        """Kriging with only the k nearest data points (PyKrige's n_closest_points, loop backend)."""
        n = self.x.size
        k = min(k, n)
        tree = cKDTree(self._xy)
        npt = pts.shape[0]
        z = np.empty(npt)
        ss = np.empty(npt)
        for s in range(0, npt, max(1, chunk_size // 4)):
            p = pts[s:s + max(1, chunk_size // 4)]
            bd, idx = tree.query(p, k=k, eps=0.0)
            if k == 1:
                bd, idx = bd[:, None], idx[:, None]
            m = p.shape[0]
            sel = np.concatenate([idx, np.full((m, 1), n)], axis=1)
            a = self._a[sel[:, :, None], sel[:, None, :]]
            b = np.empty((m, k + 1))
            b[:, :k] = -self.variogram(bd)
            if self.exact_values:
                b[:, :k][np.abs(bd) <= EPS] = 0.0
            b[:, k] = 1.0
            xw = np.linalg.solve(a, b[:, :, None])[:, :, 0]
            z[s:s + m] = np.sum(xw[:, :k] * self.z[idx], axis=1)
            ss[s:s + m] = np.sum(xw * -b, axis=1)
        return z, ss


# --------------------------------------------------------------------------- other interpolators
def idw_grid(x, y, z, gx, gy, power: float = 2.0, n_neighbors: int | None = None,
             chunk_size: int = 32768) -> np.ndarray:
    """Inverse distance weighting (exact at data points)."""
    xy = np.column_stack([np.asarray(x, float), np.asarray(y, float)])
    z = np.asarray(z, float)
    gx = np.asarray(gx, float)
    gy = np.asarray(gy, float)
    pts = _grid_points(gx, gy)
    out = np.empty(pts.shape[0])
    tree = cKDTree(xy) if n_neighbors else None
    for s in range(0, pts.shape[0], chunk_size):
        p = pts[s:s + chunk_size]
        if tree is not None:
            d, idx = tree.query(p, k=min(n_neighbors, len(z)))
            if d.ndim == 1:
                d, idx = d[:, None], idx[:, None]
            vals = z[idx]
        else:
            d = cdist(p, xy)
            vals = np.broadcast_to(z, d.shape)
        with np.errstate(divide="ignore"):
            w = 1.0 / d ** power
        exact = d <= EPS
        hit = exact.any(axis=1)
        w[hit] = exact[hit].astype(float)
        out[s:s + chunk_size] = np.sum(w * vals, axis=1) / np.sum(w, axis=1)
    return out.reshape(gy.size, gx.size)


def rbf_grid(x, y, z, gx, gy, kernel: str = "thin_plate_spline", smoothing: float = 0.0,
             epsilon: float | None = None, neighbors: int | None = None,
             chunk_size: int = 65536) -> np.ndarray:
    """Radial basis function interpolation (scipy RBFInterpolator); coordinates are rescaled to ~unit size."""
    from scipy.interpolate import RBFInterpolator

    xy = np.column_stack([np.asarray(x, float), np.asarray(y, float)])
    gx = np.asarray(gx, float)
    gy = np.asarray(gy, float)
    center = xy.mean(axis=0)
    scale = float(np.max(np.ptp(xy, axis=0))) or 1.0
    kw = {"kernel": kernel, "smoothing": smoothing, "neighbors": neighbors}
    if epsilon is not None:
        kw["epsilon"] = epsilon
    elif kernel in ("gaussian", "multiquadric", "inverse_multiquadric", "inverse_quadratic"):
        kw["epsilon"] = 1.0
    rbf = RBFInterpolator((xy - center) / scale, np.asarray(z, float), **kw)
    pts = (_grid_points(gx, gy) - center) / scale
    out = np.empty(pts.shape[0])
    for s in range(0, pts.shape[0], chunk_size):
        out[s:s + chunk_size] = rbf(pts[s:s + chunk_size])
    return out.reshape(gy.size, gx.size)
