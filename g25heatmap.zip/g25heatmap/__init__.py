"""G25 genetic-distance heatmap generator."""

__version__ = "0.1.0"
