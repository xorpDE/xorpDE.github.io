"""Geographic helpers: Web-Mercator (EPSG:3857) projection, grids and fast polygon masks.

Everything the renderer draws lives in EPSG:3857 metres, the same projection web-map
tiles use.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import numpy as np

R_EARTH = 6378137.0
MAX_LAT = 85.05112878
DATA_DIR = Path(__file__).resolve().parent / "data"


# --------------------------------------------------------------------------- projection
def lonlat_to_merc(lon, lat):
    """Longitude/latitude in degrees -> EPSG:3857 x/y in metres."""
    lon = np.asarray(lon, dtype=float)
    lat = np.clip(np.asarray(lat, dtype=float), -MAX_LAT, MAX_LAT)
    x = R_EARTH * np.radians(lon)
    y = R_EARTH * np.log(np.tan(np.pi / 4.0 + np.radians(lat) / 2.0))
    return x, y


def merc_to_lonlat(x, y):
    """EPSG:3857 x/y in metres -> longitude/latitude in degrees."""
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    lon = np.degrees(x / R_EARTH)
    lat = np.degrees(2.0 * np.arctan(np.exp(y / R_EARTH)) - np.pi / 2.0)
    return lon, lat


def lonlat_to_xyz(lon, lat) -> np.ndarray:
    """Points on the sphere (metres); straight-line distances between them are chord lengths."""
    lon = np.radians(np.asarray(lon, dtype=float))
    lat = np.radians(np.asarray(lat, dtype=float))
    c = np.cos(lat)
    return R_EARTH * np.column_stack([c * np.cos(lon), c * np.sin(lon), np.sin(lat)])


@dataclass(frozen=True)
class Extent:
    """Map window in EPSG:3857 metres."""

    xmin: float
    xmax: float
    ymin: float
    ymax: float

    @property
    def width(self) -> float:
        return self.xmax - self.xmin

    @property
    def height(self) -> float:
        return self.ymax - self.ymin

    @property
    def aspect(self) -> float:
        return self.width / self.height

    def buffered(self, frac: float) -> "Extent":
        dx, dy = self.width * frac, self.height * frac
        return Extent(self.xmin - dx, self.xmax + dx, self.ymin - dy, self.ymax + dy)

    def contains(self, x, y):
        x = np.asarray(x)
        y = np.asarray(y)
        return (x >= self.xmin) & (x <= self.xmax) & (y >= self.ymin) & (y <= self.ymax)

    def lonlat_bounds(self):
        (lon0, lon1), (lat0, lat1) = merc_to_lonlat([self.xmin, self.xmax], [self.ymin, self.ymax])
        return float(lon0), float(lat0), float(lon1), float(lat1)

    @classmethod
    def from_lonlat(cls, lon0, lat0, lon1, lat1) -> "Extent":
        (x0, x1), (y0, y1) = lonlat_to_merc([lon0, lon1], [lat0, lat1])
        return cls(float(x0), float(x1), float(y0), float(y1))


def make_grid(extent: Extent, nx: int, ny: int):
    """Regular grid of points spanning the extent (first/last points on the edges)."""
    gx = np.linspace(extent.xmin, extent.xmax, int(nx))
    gy = np.linspace(extent.ymin, extent.ymax, int(ny))
    return gx, gy


# --------------------------------------------------------------------------- polygons
def _iter_rings(geometry):
    gtype = geometry["type"]
    if gtype == "Polygon":
        polys = [geometry["coordinates"]]
    elif gtype == "MultiPolygon":
        polys = geometry["coordinates"]
    else:
        return
    for poly in polys:
        for ring in poly:
            if len(ring) >= 3:
                yield np.asarray(ring, dtype=float)[:, :2]


@lru_cache(maxsize=4)
def load_rings(path: str | None = None):
    """Load every polygon ring of a GeoJSON file, projected to EPSG:3857.

    Returns a list of (N, 2) arrays.  Exterior rings and holes are mixed: the
    even-odd fill rule used by :func:`rasterize_rings` handles holes correctly.
    """
    path = Path(path) if path else DATA_DIR / "land.geojson"
    with open(path, encoding="utf-8") as fh:
        gj = json.load(fh)
    feats = gj["features"] if gj.get("type") == "FeatureCollection" else [gj]
    rings = []
    for feat in feats:
        geom = feat.get("geometry", feat)
        if not geom:
            continue
        for ring in _iter_rings(geom):
            # Rings crossing the antimeridian are left as-is; the regions we draw never need them.
            x, y = lonlat_to_merc(ring[:, 0], ring[:, 1])
            rings.append(np.column_stack([x, y]))
    return rings


@lru_cache(maxsize=4)
def load_polygons(path: str | None = None):
    """Polygons of a GeoJSON file as lists of rings [exterior, hole, ...], projected to EPSG:3857."""
    path = Path(path) if path else DATA_DIR / "land.geojson"
    with open(path, encoding="utf-8") as fh:
        gj = json.load(fh)
    feats = gj["features"] if gj.get("type") == "FeatureCollection" else [gj]
    polys = []
    for feat in feats:
        geom = feat.get("geometry", feat)
        if not geom:
            continue
        parts = [geom["coordinates"]] if geom["type"] == "Polygon" else geom["coordinates"]
        for part in parts:
            rings = []
            for ring in part:
                a = np.asarray(ring, dtype=float)[:, :2]
                if len(a) >= 3:
                    x, y = lonlat_to_merc(a[:, 0], a[:, 1])
                    rings.append(np.column_stack([x, y]))
            if rings:
                polys.append(rings)
    return polys


def rasterize_rings(rings, gx, gy) -> np.ndarray:
    """Even-odd point-in-polygon test for every grid point (exact, vectorised scanline).

    ``gx`` and ``gy`` must be increasing.  Returns a bool array of shape (len(gy), len(gx))
    where row 0 is the southernmost row (gy[0]).
    """
    gx = np.asarray(gx, dtype=float)
    gy = np.asarray(gy, dtype=float)
    nx, ny = len(gx), len(gy)
    x0g, x1g, y0g, y1g = gx[0], gx[-1], gy[0], gy[-1]

    starts, ends = [], []
    for ring in rings:
        if (ring[:, 0].max() < x0g or ring[:, 0].min() > x1g or
                ring[:, 1].max() < y0g or ring[:, 1].min() > y1g):
            continue
        a = ring
        b = np.roll(ring, -1, axis=0)  # closes the ring even if the last point != first
        starts.append(a)
        ends.append(b)
    if not starts:
        return np.zeros((ny, nx), dtype=bool)
    a = np.concatenate(starts)
    b = np.concatenate(ends)
    ya, yb = a[:, 1], b[:, 1]
    keep = ya != yb  # horizontal edges never cross a scanline
    a, b, ya, yb = a[keep], b[keep], ya[keep], yb[keep]
    ylo = np.minimum(ya, yb)
    yhi = np.maximum(ya, yb)

    # Scanline rows j with ylo <= gy[j] < yhi (half-open avoids double counting at vertices).
    j0 = np.searchsorted(gy, ylo, side="left")
    j1 = np.searchsorted(gy, yhi, side="left")
    count = j1 - j0
    has = count > 0
    if not np.any(has):
        return np.zeros((ny, nx), dtype=bool)
    a, b, j0, count = a[has], b[has], j0[has], count[has]
    edge_idx = np.repeat(np.arange(len(a)), count)
    offsets = np.arange(edge_idx.size) - np.repeat(np.cumsum(count) - count, count)
    rows = j0[edge_idx] + offsets
    yrow = gy[rows]
    ax_, ay_ = a[edge_idx, 0], a[edge_idx, 1]
    bx_, by_ = b[edge_idx, 0], b[edge_idx, 1]
    t = (yrow - ay_) / (by_ - ay_)
    xcross = ax_ + t * (bx_ - ax_)

    order = np.lexsort((xcross, rows))
    rows = rows[order]
    xcross = xcross[order]
    # Within each row crossings come in pairs (enter, leave) under the even-odd rule.
    row_start = np.searchsorted(rows, np.arange(ny), side="left")
    rank = np.arange(rows.size) - row_start[rows]
    enter = (rank % 2) == 0
    # Pair each "enter" crossing with the next crossing in the same row.
    idx_enter = np.nonzero(enter)[0]
    idx_leave = idx_enter + 1
    valid = idx_leave < rows.size
    idx_enter, idx_leave = idx_enter[valid], idx_leave[valid]
    same_row = rows[idx_enter] == rows[idx_leave]
    idx_enter, idx_leave = idx_enter[same_row], idx_leave[same_row]

    c0 = np.searchsorted(gx, xcross[idx_enter], side="left")
    c1 = np.searchsorted(gx, xcross[idx_leave], side="left")
    diff = np.zeros((ny, nx + 1), dtype=np.int32)
    np.add.at(diff, (rows[idx_enter], c0), 1)
    np.add.at(diff, (rows[idx_enter], c1), -1)
    return np.cumsum(diff[:, :nx], axis=1) > 0


DETAIL_SPAN_M = 3.0e6  # windows smaller than ~3000 km use the detailed (1:10m) coastline


def land_file(extent: "Extent", default: str | Path | None = None) -> str:
    """Coastline file for a map window: detailed for small (zoomed-in) windows, standard otherwise."""
    detailed = DATA_DIR / "land_10m.geojson"
    if extent.width < DETAIL_SPAN_M and extent.height < DETAIL_SPAN_M and detailed.is_file():
        return str(detailed)
    return str(default or DATA_DIR / "land.geojson")


def land_mask(gx, gy, path: str | None = None) -> np.ndarray:
    """Boolean land mask on the grid (True = land), rows south -> north."""
    return rasterize_rings(load_rings(str(path) if path else None), gx, gy)
