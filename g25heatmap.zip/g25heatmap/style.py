"""House style of the maps (colours, sizes, fonts)."""
from __future__ import annotations

from dataclasses import dataclass, field

# 14 colour bands, closest -> farthest, as they appear in the colourbar.
COLORBAR_COLORS = [
    "#bb0d31", "#d0363f", "#e4614c", "#ee8751", "#f6ac57", "#f8c659", "#eed85c",
    "#d5e361", "#acdf6a", "#74cf7a", "#59bea1", "#4caecf", "#338ec2", "#186aa8",
]


def _darken(hex_color: str, amount: int) -> str:
    r, g, b = (int(hex_color[i:i + 2], 16) for i in (1, 3, 5))
    r, g, b = (max(0, c - amount) for c in (r, g, b))
    return f"#{r:02x}{g:02x}{b:02x}"


# On the map itself every band is drawn 7 levels darker per channel than in the colourbar.
MAP_COLORS = [_darken(c, 7) for c in COLORBAR_COLORS]

SEA_COLOR = "#888888"  # uniform gray where there is no land


@dataclass
class MapStyle:
    """All tunable rendering parameters (defaults reproduce the reference look)."""

    dpi: int = 300
    # geometry in inches (map box 2569 x 2209 px at 300 dpi)
    map_width_in: float = 2569 / 300
    map_height_in: float = 2209 / 300
    cbar_gap_in: float = 54.5 / 300
    cbar_width_in: float = 81 / 300
    cbar_height_in: float = 1623 / 300
    pad_inches: float = 0.1

    n_bands: int = 14
    colorbar_colors: list = field(default_factory=lambda: list(COLORBAR_COLORS))
    map_colors: list = field(default_factory=lambda: list(MAP_COLORS))
    sea_color: str = SEA_COLOR

    title_size: float = 14.0
    tick_label_size: float = 10.0
    cbar_label: str = "Genetic distance"
    cbar_label_size: float = 10.0
    cbar_outline_width: float = 0.8

    contour_step: float = 0.01
    contour_color: str = "black"
    contour_width: float = 0.3
    contour_alpha: float = 0.65
    contour_label_size: float = 6.0
    contour_label_fmt: str = "%.2f"

    attribution_size: float = 8.0
    attribution_stroke: float = 2.0
    projection_text: str = ""        # e.g. "Projection: EPSG:3857" to print it in the corner
    projection_size: float = 7.0

    labels_enabled: bool = True     # faint country names under the gray (only with basemap "labels")
    render_mode: str = "smooth"     # "smooth": vector bands clipped to the real coastline; "raster": grid cells
    raster_mode: str = "centered"   # raster mode: grid points are cell centres; half cells cut at the map edge
