from __future__ import annotations
import os
import tomllib
from dataclasses import dataclass, field, fields
from pathlib import Path
from .style import MapStyle
PACKAGE_DIR = Path(__file__).resolve().parent
PROJECT_DIR = PACKAGE_DIR.parent
DATA_DIR = PACKAGE_DIR / 'data'

@dataclass
class Settings:
    brand: str = 'Xorpde Heatmap'
    reference_g25: Path = DATA_DIR / 'reference_g25.csv'
    reference_locations: Path = DATA_DIR / 'population_locations.csv'
    land_geojson: Path = DATA_DIR / 'land.geojson'
    output_dir: Path = PROJECT_DIR / 'output'
    basemap: str = 'plain'
    labels_attribution: str = 'Made with Natural Earth'
    plain_attribution: str = 'Made with Natural Earth'
    tile_url: str = 'https://{s}.basemaps.cartocdn.com/rastertiles/light_all/{z}/{x}/{y}.png?api_key={key}'
    tile_subdomains: str = 'abcd'
    tile_api_key: str = ''
    tile_zoom: int = 0
    tile_attribution: str = '(C) OpenStreetMap contributors (C) CARTO'
    tile_overlay_color: str = '#808080'
    tile_overlay_alpha: float = 0.9
    cache_dir: Path = PROJECT_DIR / '.cache' / 'tiles'
    style_overrides: dict = field(default_factory=dict)

    def style(self) -> MapStyle:
        st = MapStyle()
        valid = {f.name for f in fields(MapStyle)}
        for k, v in self.style_overrides.items():
            if k in valid:
                setattr(st, k, v)
        return st

    @property
    def api_key(self) -> str:
        return os.environ.get('G25_TILE_API_KEY', '') or self.tile_api_key

def load_settings(path: str | Path | None=None) -> Settings:
    s = Settings()
    cfg_path = Path(path) if path else Path(os.environ.get('G25HEATMAP_CONFIG', PROJECT_DIR / 'config.toml'))
    if not cfg_path.is_file():
        if path or os.environ.get('G25HEATMAP_CONFIG'):
            raise FileNotFoundError(f'config file not found: {cfg_path}')
        return s
    with open(cfg_path, 'rb') as fh:
        data = tomllib.load(fh)
    base = cfg_path.parent
    for f in fields(Settings):
        if f.name == 'style_overrides' or f.name not in data:
            continue
        val = data[f.name]
        if isinstance(getattr(s, f.name), Path):
            p = Path(val)
            val = p if p.is_absolute() else base / p
        setattr(s, f.name, val)
    if isinstance(data.get('style'), dict):
        s.style_overrides = dict(data['style'])
    return s
