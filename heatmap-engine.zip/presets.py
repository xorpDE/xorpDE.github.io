from __future__ import annotations
from dataclasses import dataclass
from .geo import Extent

@dataclass(frozen=True)
class Preset:
    key: str
    title: str
    extent: Extent
    nx: int = 720
    ny: int = 720
    buffer: float = 0.15
    geometry: str = 'plane'
    description: str = ''

def _ll(lon0, lat0, lon1, lat1) -> Extent:
    return Extent.from_lonlat(lon0, lat0, lon1, lat1)
PRESETS: dict[str, Preset] = {'world': Preset(key='world', title='World', extent=_ll(-180.0, -56.0, 180.0, 72.0), nx=1080, ny=540, buffer=0.0, geometry='sphere', description='The whole inhabited world (Antarctica and the high Arctic left out)'), 'europe': Preset(key='europe', title='Europe', extent=Extent(-1188577.0, 4243387.0, 4073658.0, 8744662.0), description='Europe with the Mediterranean rim (lon -10.7..38.1, lat 34.3..61.5)'), 'balkans': Preset(key='balkans', title='Balkans', extent=_ll(2.5, 33.0, 41.0, 51.0), nx=900, ny=572, description='The Balkans in the centre, with Italy, Central and Eastern Europe, Ukraine and Turkiye'), 'mediterranean': Preset(key='mediterranean', title='Mediterranean', extent=_ll(-10.5, 29.0, 43.0, 48.5), nx=1040, ny=492, description='The Mediterranean basin: Iberia, Italy, the Balkans, Anatolia, the Levant, North Africa'), 'eastern_mediterranean': Preset(key='eastern_mediterranean', title='Eastern Mediterranean', extent=_ll(18.0, 28.5, 42.0, 44.0), nx=720, ny=580, description='Greece and the Aegean, the southern Balkans, Anatolia, Cyprus, the Levant, Lower Egypt'), 'middle_east': Preset(key='middle_east', title='Middle East', extent=_ll(24.0, 12.0, 64.0, 43.5), description='Anatolia, the Levant, Mesopotamia, Arabia, Iran'), 'central_asia': Preset(key='central_asia', title='Caucasus & Central Asia', extent=_ll(36.0, 30.0, 92.0, 57.0), description='Caucasus, Caspian region, Central Asia, Volga-Ural'), 'south_asia': Preset(key='south_asia', title='South Asia', extent=_ll(60.0, 5.0, 98.0, 38.0), description='Afghanistan, Pakistan, India, Nepal, Bangladesh, Sri Lanka'), 'east_asia': Preset(key='east_asia', title='East Asia', extent=_ll(94.0, 17.0, 147.0, 54.0), description='China, Mongolia, Korea, Japan'), 'southeast_asia': Preset(key='southeast_asia', title='Southeast Asia & Oceania', extent=_ll(90.0, -48.0, 180.0, 28.0), geometry='sphere', description='Mainland and island Southeast Asia, New Guinea, Australia, the western Pacific'), 'africa': Preset(key='africa', title='Africa', extent=_ll(-20.0, -36.0, 56.0, 38.0), geometry='sphere', description='The whole African continent'), 'north_america': Preset(key='north_america', title='North America', extent=_ll(-170.0, 7.0, -50.0, 72.0), geometry='sphere', description='North and Central America'), 'south_america': Preset(key='south_america', title='South America', extent=_ll(-92.0, -56.0, -32.0, 14.0), geometry='sphere', description='South America')}

def custom_preset(xmin: float, xmax: float, ymin: float, ymax: float, title: str='View') -> Preset:
    ext = Extent(float(xmin), float(xmax), float(ymin), float(ymax))
    if not (ext.width > 1000 and ext.height > 1000):
        raise ValueError('the map window is too small')
    lon0, lat0, lon1, lat1 = ext.lonlat_bounds()
    big = lon1 - lon0 > 90 or lat1 - lat0 > 50
    if ext.aspect >= 1:
        nx, ny = (720, max(120, int(round(720 / ext.aspect))))
    else:
        nx, ny = (max(120, int(round(720 * ext.aspect))), 720)
    return Preset(key='view', title=title, extent=ext, nx=nx, ny=ny, buffer=0.15, geometry='sphere' if big else 'plane', description='custom map window')

def get_preset(key: str) -> Preset:
    try:
        return PRESETS[key.lower()]
    except KeyError as exc:
        raise KeyError(f"unknown region '{key}', choose from: {', '.join(PRESETS)}") from exc
