from __future__ import annotations
import csv
import re
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np
N_DIMS = 25

class CoordinateError(ValueError):
    pass

@dataclass
class Sample:
    name: str
    vector: np.ndarray

def _to_float(p: str):
    try:
        return float(p)
    except ValueError:
        return None

def _parse_line(line: str, lineno: int) -> Sample | None:
    line = line.replace('\ufeff', '').replace('\u200b', '').replace('−', '-').strip()
    if not line or line.startswith('#'):
        return None
    if re.search('[,;\\t]', line):
        if re.search('[;\\t]', line) and (not re.search('\\d\\.\\d', line)):
            line = re.sub('(?<=\\d),(?=\\d)', '.', line)
        parts = [p.strip().strip('"\'').strip() for p in re.split('[,;\\t]', line)]
    else:
        parts = line.split()
    parts = [p for p in parts if p]
    if not parts:
        return None
    vals = [_to_float(p) for p in parts]
    first = next((i for i, v in enumerate(vals) if v is not None), None)
    if first is None:
        return None
    if len(vals) - first > N_DIMS and all((v is not None for v in vals[first:])):
        first = len(vals) - N_DIMS
    bad = next((p for p, v in zip(parts[first:], vals[first:]) if v is None), None)
    if bad is not None:
        raise CoordinateError(f"line {lineno}: unexpected text '{bad}' after the numbers")
    nums = vals[first:]
    if len(nums) != N_DIMS:
        raise CoordinateError(f'line {lineno}: expected {N_DIMS} numbers but found {len(nums)} (paste the full G25 line: Name,PC1,...,PC25)')
    if not np.all(np.isfinite(nums)):
        raise CoordinateError(f'line {lineno}: the coordinates must be finite numbers')
    name = ' '.join(parts[:first]).strip() or f'Sample{lineno}'
    return Sample(name=name, vector=np.asarray(nums, dtype=float))

def parse_coordinates(text: str) -> list[Sample]:
    samples = []
    for i, line in enumerate(text.splitlines(), start=1):
        s = _parse_line(line, i)
        if s is not None:
            samples.append(s)
    if not samples:
        raise CoordinateError('no G25 coordinates found')
    return samples

def average_samples(samples: list[Sample], name: str | None=None) -> Sample:
    vec = np.mean([s.vector for s in samples], axis=0)
    return Sample(name=name or (samples[0].name if len(samples) == 1 else 'Average'), vector=vec)

def euclidean_distances(target: np.ndarray, matrix: np.ndarray) -> np.ndarray:
    diff = np.asarray(matrix, dtype=float) - np.asarray(target, dtype=float)[None, :]
    return np.sqrt(np.einsum('ij,ij->i', diff, diff))

@dataclass
class ReferenceSet:
    labels: list[str]
    vectors: np.ndarray
    lon: np.ndarray
    lat: np.ndarray
    region: list[str] = field(default_factory=list)
    country: list[str] = field(default_factory=list)
    weight: np.ndarray | None = None

    def __len__(self) -> int:
        return len(self.labels)

    def subset(self, keep) -> 'ReferenceSet':
        keep = np.asarray(keep)
        if keep.dtype == bool:
            idx = np.nonzero(keep)[0]
        else:
            idx = keep
        pick = lambda seq: [seq[i] for i in idx] if seq else []
        return ReferenceSet(labels=pick(self.labels), vectors=self.vectors[idx], lon=self.lon[idx], lat=self.lat[idx], region=pick(self.region), country=pick(self.country), weight=None if self.weight is None else self.weight[idx])

def read_g25_csv(path: str | Path) -> tuple[list[str], np.ndarray]:
    labels, rows = ([], [])
    with open(path, encoding='utf-8-sig', newline='') as fh:
        for rec in csv.reader(fh):
            if not rec or rec[0].startswith('#'):
                continue
            try:
                vals = [float(v) for v in rec[1:1 + N_DIMS]]
            except ValueError:
                continue
            if len(vals) != N_DIMS:
                continue
            labels.append(rec[0].strip())
            rows.append(vals)
    return (labels, np.asarray(rows, dtype=float))

def _truthy(value: str) -> bool:
    return str(value).strip().lower() in {'1', 'true', 'yes', 'y'}

def load_reference(g25_csv: str | Path, locations_csv: str | Path) -> ReferenceSet:
    labels, vectors = read_g25_csv(g25_csv)
    index = {lab: i for i, lab in enumerate(labels)}
    out_labels, out_vecs, lon, lat, region, country, weight = ([], [], [], [], [], [], [])
    with open(locations_csv, encoding='utf-8-sig', newline='') as fh:
        for row in csv.DictReader(fh):
            lab = (row.get('label') or '').strip()
            if not lab or lab not in index:
                continue
            if 'include' in row and row['include'] not in (None, '') and (not _truthy(row['include'])):
                continue
            try:
                la, lo = (float(row['lat']), float(row['lon']))
            except (TypeError, ValueError, KeyError):
                continue
            out_labels.append(lab)
            out_vecs.append(vectors[index[lab]])
            lat.append(la)
            lon.append(lo)
            region.append((row.get('region') or '').strip())
            country.append((row.get('country') or '').strip())
            try:
                weight.append(float(row.get('n') or 'nan'))
            except ValueError:
                weight.append(float('nan'))
    if not out_labels:
        raise ValueError('no reference populations matched between the G25 table and the location table')
    return ReferenceSet(labels=out_labels, vectors=np.asarray(out_vecs, dtype=float), lon=np.asarray(lon, dtype=float), lat=np.asarray(lat, dtype=float), region=region, country=country, weight=np.asarray(weight, dtype=float))
