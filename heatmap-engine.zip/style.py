from __future__ import annotations
from dataclasses import dataclass, field
BAND_COLORS = ['#b71126', '#d93429', '#ed5f3c', '#f98e52', '#fdb96b', '#fedc8c', '#fff3ad', '#f3fbd4', '#dcf1f7', '#b6dfec', '#8ec2dc', '#69a0ca', '#4878b6', '#384ca0']
SEA_COLOR = '#a9a9a9'

@dataclass
class MapStyle:
    dpi: int = 300
    map_width_in: float = 2569 / 300
    map_height_in: float = 2209 / 300
    cbar_gap_in: float = 54.5 / 300
    cbar_width_in: float = 60 / 300
    cbar_height_in: float = 1250 / 300
    pad_inches: float = 0.1
    n_bands: int = 28
    colorbar_colors: list = field(default_factory=lambda: list(BAND_COLORS))
    map_colors: list = field(default_factory=lambda: list(BAND_COLORS))
    sea_color: str = SEA_COLOR
    font_family: str = 'Inter'
    coast_width: float = 0.0
    coast_color: str = '#3a3a3a'
    coast_alpha: float = 0.7
    title_size: float = 15.0
    title_layout: str = 'headline'
    title_weight: str = 'bold'
    subtitle_text: str = 'Genetic distance map'
    subtitle_size: float = 9.0
    subtitle_color: str = '#555555'
    tick_label_size: float = 10.0
    cbar_label: str = 'Genetic distance (lower = closer)'
    cbar_label_size: float = 10.0
    cbar_outline_width: float = 0.8
    cbar_orientation: str = 'footer'
    footer_height_in: float = 0.8
    footer_gap_in: float = 0.2
    footer_bar_frac: float = 0.5
    footer_bar_style: str = 'flat'
    footer_label_color: str = '#6b6b6b'
    footer_text_color: str = '#222222'
    footer_rule_color: str = '#d9d9d9'
    cbar_valign: str = 'top'
    cbar_ticks: str = 'round'
    hbar_width_frac: float = 0.55
    hbar_height_in: float = 0.16
    hbar_gap_in: float = 0.22
    contour_step: float = 0.01
    contour_color: str = '#2b2b2b'
    contour_width: float = 0.45
    contour_alpha: float = 0.55
    contour_label_size: float = 8.0
    contour_label_fmt: str = '%.2f'
    contour_label_every: int = 2
    contour_label_color: str = '#111111'
    contour_label_halo: float = 0.0
    contour_label_light_color: str = '#ffffff'
    contour_label_ground: float = 0.0
    contour_label_on_land: bool = True
    contour_label_min_contrast: float = 3.0
    contour_label_font: str = 'DejaVu Sans'
    attribution_size: float = 8.0
    attribution_stroke: float = 2.0
    projection_text: str = ''
    projection_size: float = 7.0
    settings_size: float = 8.0
    labels_enabled: bool = True
    render_mode: str = 'smooth'
    raster_mode: str = 'centered'
DEEP_RED_BLUE_14 = ['#67000d', '#a50f15', '#cb181d', '#ef3b2c', '#fb6a4a', '#fc9272', '#fcbba1', '#c6dbef', '#9ecae1', '#6baed6', '#4292c6', '#2171b5', '#08519c', '#08306b']
VIRIDIS_14 = ['#e7e419', '#b8de29', '#89d548', '#5cc863', '#3aba76', '#24aa83', '#1f998a', '#24878e', '#2a768e', '#32658e', '#3b518b', '#433d84', '#482677', '#470e61']
THEMES = {'standard': {}, 'bold': dict(colorbar_colors=DEEP_RED_BLUE_14, map_colors=DEEP_RED_BLUE_14, sea_color='#9a9a9a'), 'viridis': dict(colorbar_colors=VIRIDIS_14, map_colors=VIRIDIS_14, sea_color='#ffffff', coast_width=0.35)}
DEFAULT_THEME = 'standard'

def themed(st: MapStyle, theme: str | None) -> MapStyle:
    for k, v in THEMES.get(theme or DEFAULT_THEME, {}).items():
        setattr(st, k, list(v) if isinstance(v, list) else v)
    return st
