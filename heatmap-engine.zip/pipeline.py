from __future__ import annotations
import re
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
import numpy as np
from . import geo
from .config import Settings, load_settings
from .g25 import ReferenceSet, Sample, euclidean_distances, load_reference
from .presets import Preset, get_preset
from .render import DistanceField, render_map
from .style import MapStyle

@dataclass
class MapOptions:
    region: str = 'europe'
    max_distance: float = 0.1
    method: str = 'kriging'
    variogram: str = 'exponential'
    nlags: int = 6
    weight: bool = False
    smoothing: float = 0.05
    variogram_parameters: list | None = None
    idw_power: float = 2.0
    rbf_smoothing: float = 0.0
    min_samples: int = 2
    exclude: list[str] = field(default_factory=list)
    include_only: list[str] = field(default_factory=list)
    title: str | None = None
    preset: object | None = None
    references: object | None = None
    samples_name: str = ''

@lru_cache(maxsize=4)
def _cached_reference(g25_csv: str, locations_csv: str, _m1: int=0, _m2: int=0) -> ReferenceSet:
    return load_reference(g25_csv, locations_csv)

def reference_set(settings: Settings | None=None) -> ReferenceSet:
    s = settings or load_settings()
    g, l = (Path(s.reference_g25), Path(s.reference_locations))
    return _cached_reference(str(g), str(l), g.stat().st_mtime_ns, l.stat().st_mtime_ns)
SAMPLE_SETS = {'moriopoulos': ('Advanced Moriopoulos', None, None, 2), 'makedonas': ('Makedonas G25', 'makedonas_g25.csv', 'makedonas_locations.csv', 2)}
DEFAULT_SAMPLE_SET = 'moriopoulos'

def sample_set(key: str | None, settings: Settings | None=None):
    s = settings or load_settings()
    key = key if key in SAMPLE_SETS else DEFAULT_SAMPLE_SET
    name, g25, places, min_samples = SAMPLE_SETS[key]
    if g25 is None:
        return (key, name, reference_set(s), min_samples)
    folder = Path(s.reference_g25).parent
    g, l = (folder / g25, folder / places)
    return (key, name, _cached_reference(str(g), str(l), g.stat().st_mtime_ns, l.stat().st_mtime_ns), min_samples)

def select_references(refs: ReferenceSet, preset: Preset, opts: MapOptions) -> ReferenceSet:
    x, y = geo.lonlat_to_merc(refs.lon, refs.lat)
    keep = preset.extent.buffered(preset.buffer).contains(x, y)
    if opts.min_samples > 1 and refs.weight is not None:
        keep &= ~(refs.weight < opts.min_samples)
    labels = np.array(refs.labels, dtype=object)
    if opts.include_only:
        pat = re.compile('|'.join(opts.include_only), re.IGNORECASE)
        keep &= np.array([bool(pat.search(l)) for l in labels])
    if opts.exclude:
        pat = re.compile('|'.join(opts.exclude), re.IGNORECASE)
        keep &= np.array([not pat.search(l) for l in labels])
    return refs.subset(keep)

def interpolate(x, y, values, gx, gy, opts: MapOptions, geometry: str='plane') -> np.ndarray:
    from . import kriging
    x, y, values = kriging.merge_duplicate_locations(x, y, values)
    method = opts.method.lower()
    if method == 'kriging':
        pts = None
        if geometry == 'sphere':
            lon, lat = geo.merc_to_lonlat(x, y)
            pts = geo.lonlat_to_xyz(lon, lat)
        params = opts.variogram_parameters
        if params is None and opts.smoothing > 0 and (opts.variogram not in ('linear', 'power')):
            if pts is not None:
                fitted = kriging.fit_variogram_points(pts, values, opts.variogram, opts.nlags, opts.weight)
            else:
                fitted = kriging.fit_variogram(x, y, values, opts.variogram, opts.nlags, opts.weight)
            psill, rng, nugget = fitted.params
            sill = psill + nugget
            params = [sill, rng, max(nugget, opts.smoothing * sill)]
        ok = kriging.OrdinaryKriging(x, y, values, variogram_model=opts.variogram, variogram_parameters=params, nlags=opts.nlags, weight=opts.weight, coords=pts)
        if pts is not None:
            GX, GY = np.meshgrid(gx, gy)
            glon, glat = geo.merc_to_lonlat(GX.ravel(), GY.ravel())
            return ok.execute_coords(geo.lonlat_to_xyz(glon, glat)).reshape(len(gy), len(gx))
        return ok.execute_grid(gx, gy)
    if method == 'idw':
        return kriging.idw_grid(x, y, values, gx, gy, power=opts.idw_power)
    if method == 'rbf':
        return kriging.rbf_grid(x, y, values, gx, gy, smoothing=opts.rbf_smoothing)
    raise ValueError(f"unknown interpolation method '{opts.method}'")

@dataclass
class FieldResult:
    field: DistanceField
    references: ReferenceSet
    distances: np.ndarray
    closest: float | None = None

def compute_field(target: np.ndarray, opts: MapOptions, settings: Settings | None=None) -> FieldResult:
    s = settings or load_settings()
    preset = opts.preset or get_preset(opts.region)
    refs = select_references(opts.references if opts.references is not None else reference_set(s), preset, opts)
    if len(refs) < 3:
        raise ValueError('fewer than 3 reference populations inside this map region')
    d = euclidean_distances(target, refs.vectors)
    x, y = geo.lonlat_to_merc(refs.lon, refs.lat)
    gx, gy = geo.make_grid(preset.extent, preset.nx, preset.ny)
    z = interpolate(x, y, d, gx, gy, opts, preset.geometry)
    mask = geo.land_mask(gx, gy, geo.land_file(preset.extent, s.land_geojson))
    zm = np.ma.masked_array(z, mask=~mask)
    closest = float(max(0.0, zm.min())) if zm.count() else None
    vmin = closest if closest is not None else 0.0
    vmax = float(opts.max_distance)
    if vmin >= vmax:
        vmin = 0.0
    return FieldResult(DistanceField(gx, gy, zm, preset.extent, vmin, vmax), refs, d, closest)

def nearest_populations(target: np.ndarray, settings: Settings | None=None, n: int=15, references=None):
    refs = references if references is not None else reference_set(settings)
    d = euclidean_distances(target, refs.vectors)
    order = np.argsort(d)[:n]
    return [(refs.labels[i], float(d[i])) for i in order]
MAX_DISTANCE_NAMES = {0.05: 'maximum contrast', 0.07: 'high contrast', 0.1: 'default', 0.15: 'isolated ancestries', 0.2: 'distant regions', 0.3: 'world map'}

def settings_text(opts: MapOptions) -> str:
    md = float(opts.max_distance)
    text = f'Max distance: {md:.2f}' if round(md, 2) == md else f'Max distance: {md:g}'
    name = next((n for v, n in MAX_DISTANCE_NAMES.items() if abs(v - md) < 1e-09), None)
    if name:
        text += f'\n({name})'
    if opts.samples_name:
        text += f'\nDataset: {opts.samples_name}'
    return text

def settings_items(opts: MapOptions) -> list[tuple[str, str]]:
    md = float(opts.max_distance)
    val = f'{md:.2f}' if round(md, 2) == md else f'{md:g}'
    name = next((n for v, n in MAX_DISTANCE_NAMES.items() if abs(v - md) < 1e-09), None)
    items = [('Max distance', f'{val} ({name})' if name else val)]
    if opts.samples_name:
        items.append(('Dataset', opts.samples_name))
    return items

def make_title(sample_name: str, opts: MapOptions, settings: Settings) -> str:
    if opts.title:
        return opts.title
    brand = settings.brand.strip()
    return f'{sample_name} ({brand})' if brand else sample_name

def generate_map(sample: Sample, out_path: str | Path | None, opts: MapOptions | None=None, settings: Settings | None=None, style: MapStyle | None=None, progress=None, result_info: dict | None=None):
    from .basemap import background_for
    opts = opts or MapOptions()
    s = settings or load_settings()
    if progress:
        progress('kriging', 'Interpolating distances (kriging)…', 0.45)
    res = compute_field(sample.vector, opts, s)
    st = style or s.style()
    if progress:
        progress('drawing', 'Drawing the map…', 0.75)
    bg, attribution = background_for(res.field, st, s)
    subtitle = brand = None
    if st.title_layout == 'headline' and (not opts.title):
        title = sample.name
        subtitle = st.subtitle_text
        brand = s.brand.strip() or None
    else:
        title = make_title(sample.name, opts, s)
    if result_info is not None:
        result_info.update(title=title, vmin=res.field.vmin, vmax=res.field.vmax, closest=res.closest)
    return render_map(res.field, title, out_path, st, background=bg, attribution=attribution, layout=result_info, settings_text=settings_text(opts), subtitle=subtitle, settings_items=settings_items(opts), brand=brand)

def safe_filename(name: str) -> str:
    stem = re.sub('[^A-Za-z0-9_.-]+', '_', name.strip()).strip('._') or 'map'
    return stem[:80]
