from __future__ import annotations
import hashlib
import io
import math
import sys
import urllib.request
from pathlib import Path
import numpy as np
from PIL import Image
from .geo import R_EARTH, Extent, merc_to_lonlat
HALF_WORLD = math.pi * R_EARTH
USER_AGENT = 'g25heatmap/0.1 (+local map generator)'

class TileError(RuntimeError):
    pass

def auto_zoom(extent: Extent) -> int:
    lon0, lat0, lon1, lat1 = extent.lonlat_bounds()
    zoom_lon = math.ceil(math.log2(360 * 2.0 / max(1e-09, lon1 - lon0)))
    zoom_lat = math.ceil(math.log2(360 * 2.0 / max(1e-09, lat1 - lat0)))
    return int(max(0, min(zoom_lon, zoom_lat)))

def _tile_bytes(url: str, cache_dir: Path) -> bytes:
    cache_dir.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha1(url.encode()).hexdigest()
    path = cache_dir / f'{key}.png'
    if path.is_file():
        return path.read_bytes()
    req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as resp:
        etag = resp.headers.get('ETag', '') or ''
        data = resp.read()
    if etag.strip('"').startswith('wm-'):
        raise TileError("the tile server returned an 'API key required' placeholder; set tile_api_key / G25_TILE_API_KEY")
    Image.open(io.BytesIO(data)).verify()
    path.write_bytes(data)
    return data

def fetch_tiles(extent: Extent, width: int, height: int, url_template: str, cache_dir: Path, zoom: int=0, subdomains: str='abcd', api_key: str='') -> np.ndarray:
    z = zoom or auto_zoom(extent)
    n = 2 ** z
    tsz = 2 * HALF_WORLD / n
    tx0 = max(0, int(math.floor((extent.xmin + HALF_WORLD) / tsz)))
    tx1 = min(n - 1, int(math.floor((extent.xmax + HALF_WORLD) / tsz)))
    ty0 = max(0, int(math.floor((HALF_WORLD - extent.ymax) / tsz)))
    ty1 = min(n - 1, int(math.floor((HALF_WORLD - extent.ymin) / tsz)))
    mosaic = Image.new('RGB', ((tx1 - tx0 + 1) * 256, (ty1 - ty0 + 1) * 256), (255, 255, 255))
    for i, tx in enumerate(range(tx0, tx1 + 1)):
        for j, ty in enumerate(range(ty0, ty1 + 1)):
            s = subdomains[(tx + ty) % len(subdomains)] if subdomains else ''
            url = url_template.format(s=s, z=z, x=tx, y=ty, key=api_key, r='')
            tile = Image.open(io.BytesIO(_tile_bytes(url, cache_dir))).convert('RGB')
            if tile.size != (256, 256):
                tile = tile.resize((256, 256), Image.BILINEAR)
            mosaic.paste(tile, (i * 256, j * 256))
    mx0 = -HALF_WORLD + tx0 * tsz
    my1 = HALF_WORLD - ty0 * tsz
    px_per_m = 256 / tsz
    box = ((extent.xmin - mx0) * px_per_m, (my1 - extent.ymax) * px_per_m, (extent.xmax - mx0) * px_per_m, (my1 - extent.ymin) * px_per_m)
    out = mosaic.transform((width, height), Image.EXTENT, data=box, resample=Image.BILINEAR)
    return np.asarray(out)

def _hex_rgb(color: str) -> np.ndarray:
    color = color.lstrip('#')
    return np.array([int(color[i:i + 2], 16) for i in (0, 2, 4)], dtype=float)

def background_for(field, style, settings):
    from .render import map_box_inches
    w_in, h_in = map_box_inches(field.extent, style)
    width, height = (int(round(w_in * style.dpi)), int(round(h_in * style.dpi)))
    mode = (settings.basemap or 'labels').lower()
    if mode == 'tiles':
        try:
            tiles = fetch_tiles(field.extent, width, height, settings.tile_url, Path(settings.cache_dir), settings.tile_zoom, settings.tile_subdomains, settings.api_key).astype(float)
            a = float(settings.tile_overlay_alpha)
            img = a * _hex_rgb(settings.tile_overlay_color)[None, None, :] + (1 - a) * tiles
            return (np.clip(np.rint(img), 0, 255).astype(np.uint8), settings.tile_attribution)
        except Exception as exc:
            print(f'[g25heatmap] map tiles unavailable ({exc}); using the offline label layer', file=sys.stderr)
            mode = 'labels'
    if mode == 'labels' and style.labels_enabled:
        from .labels import label_background
        return (label_background(field.extent, width, height, style), settings.labels_attribution or None)
    return (None, settings.plain_attribution or None)
