from __future__ import annotations
import io
from dataclasses import dataclass
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import patheffects
from matplotlib.cm import ScalarMappable
from matplotlib.colors import BoundaryNorm, ListedColormap, LinearSegmentedColormap
from matplotlib.patches import PathPatch
from matplotlib.path import Path as MplPath
from matplotlib.ticker import FormatStrFormatter
from .geo import Extent, land_file, load_polygons
from .style import MapStyle

@dataclass
class DistanceField:
    gx: np.ndarray
    gy: np.ndarray
    z: np.ma.MaskedArray
    extent: Extent
    vmin: float
    vmax: float

def _band_colors(colors: list[str], n: int) -> list:
    if n == len(colors):
        return list(colors)
    cmap = LinearSegmentedColormap.from_list('bands', colors)
    return [cmap(i / max(1, n - 1)) for i in range(n)]

def _signed_area(r: np.ndarray) -> float:
    x, y = (r[:, 0], r[:, 1])
    return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))

def land_path(extent: Extent, margin: float=0.05) -> MplPath:
    box = extent.buffered(margin)
    verts, codes = ([], [])
    for poly in load_polygons(land_file(extent)):
        ext = poly[0]
        if ext[:, 0].max() < box.xmin or ext[:, 0].min() > box.xmax or ext[:, 1].max() < box.ymin or (ext[:, 1].min() > box.ymax):
            continue
        for k, ring in enumerate(poly):
            area = _signed_area(ring)
            if k == 0 and area < 0 or (k > 0 and area > 0):
                ring = ring[::-1]
            verts.append(ring)
            verts.append(ring[:1])
            codes.extend([MplPath.MOVETO] + [MplPath.LINETO] * (len(ring) - 1) + [MplPath.CLOSEPOLY])
    if not verts:
        return MplPath(np.zeros((1, 2)))
    return MplPath(np.concatenate(verts), np.asarray(codes, dtype=MplPath.code_type))

def _tick_formatter(vmin: float, vmax: float) -> FormatStrFormatter:
    step = (vmax - vmin) / 7.0
    return FormatStrFormatter('%.3f' if step >= 0.0015 else '%.4f')

def map_box_inches(extent: Extent, st: MapStyle) -> tuple[float, float]:
    default = st.map_width_in / st.map_height_in
    a = extent.aspect
    if abs(a - default) < 0.001:
        return (st.map_width_in, st.map_height_in)
    if a > default:
        return (st.map_width_in, st.map_width_in / a)
    return (st.map_height_in * a, st.map_height_in)

def band_levels(vmin: float, vmax: float, n_bands: int) -> np.ndarray:
    if not np.isfinite(vmin) or vmin >= vmax:
        vmin = 0.0 if vmax > 0 else vmax - 0.001
    return np.linspace(vmin, vmax, n_bands + 1)

def contour_levels(vmin: float, vmax: float, step: float, max_lines: int=15) -> np.ndarray:
    for s in [step] + [c for c in (0.02, 0.05, 0.1) if c > step]:
        k0 = int(np.floor(vmin / s)) + 1
        k1 = int(np.ceil(vmax / s)) - 1
        if k1 - k0 + 1 <= max_lines:
            break
    if k1 < k0:
        return np.array([])
    return np.round(np.arange(k0, k1 + 1) * s, 10)

def render_map(field: DistanceField, title: str, out_path: str | Path | None=None, style: MapStyle | None=None, background=None, attribution: str | None=None, layout: dict | None=None, settings_text: str | None=None):
    st = style or MapStyle()
    ext = field.extent
    gx, gy = (field.gx, field.gy)
    map_w, map_h = map_box_inches(ext, st)
    scale = max(0.55, map_h / (2209 / 300))
    cbar_h = st.cbar_height_in * scale
    cbar_w = st.cbar_width_in * scale
    left_m, right_m, bottom_m, top_m = (0.3, 1.6, 0.3, 0.8)
    fig_w = left_m + map_w + st.cbar_gap_in + cbar_w + right_m
    fig_h = bottom_m + map_h + top_m
    fig = plt.figure(figsize=(fig_w, fig_h), dpi=st.dpi)
    ax = fig.add_axes([left_m / fig_w, bottom_m / fig_h, map_w / fig_w, map_h / fig_h])
    cax = fig.add_axes([(left_m + map_w + st.cbar_gap_in) / fig_w, (bottom_m + (map_h - cbar_h) / 2) / fig_h, cbar_w / fig_w, cbar_h / fig_h])
    ax.set_xlim(gx[0], gx[-1])
    ax.set_ylim(gy[0], gy[-1])
    ax.set_aspect('auto')
    ax.set_axis_off()
    if background is not None:
        ax.imshow(background, extent=(gx[0], gx[-1], gy[0], gy[-1]), origin='upper', interpolation='bilinear', zorder=0)
    else:
        ax.imshow(np.array([[matplotlib.colors.to_rgb(st.sea_color)]]), extent=(gx[0], gx[-1], gy[0], gy[-1]), origin='upper', zorder=0)
    levels = band_levels(field.vmin, field.vmax, st.n_bands)
    norm = BoundaryNorm(levels, ncolors=st.n_bands)
    map_cmap = ListedColormap(_band_colors(st.map_colors, st.n_bands)).with_extremes(bad=(0, 0, 0, 0))
    z = np.ma.clip(field.z, levels[0], levels[-1])
    clev = contour_levels(field.vmin, field.vmax, st.contour_step)
    if st.render_mode == 'smooth':
        clip = PathPatch(land_path(ext), transform=ax.transData, facecolor='none', edgecolor='none')
        zfull = np.clip(np.ma.getdata(field.z).astype(float), levels[0], levels[-1])
        band_colors = _band_colors(st.map_colors, st.n_bands)
        cf = ax.contourf(gx, gy, zfull, levels=levels, colors=band_colors, antialiased=True, zorder=1)
        cf.set_edgecolor('face')
        cf.set_linewidth(0.3)
        cf.set_clip_path(clip)
        if clev.size and np.ma.count(z) > 4:
            from scipy.ndimage import binary_dilation
            near_land = binary_dilation(~np.ma.getmaskarray(field.z), iterations=1)
            cs = ax.contour(gx, gy, np.ma.masked_array(zfull, ~near_land), levels=clev, colors=st.contour_color, linewidths=st.contour_width, alpha=st.contour_alpha, zorder=2)
            cs.set_clip_path(clip)
            if cs.levels.size:
                ax.clabel(cs, fmt=st.contour_label_fmt, fontsize=st.contour_label_size, inline=True)
    else:
        dx = gx[1] - gx[0]
        dy = gy[1] - gy[0]
        if st.raster_mode == 'centered':
            img_extent = (gx[0] - dx / 2, gx[-1] + dx / 2, gy[0] - dy / 2, gy[-1] + dy / 2)
        else:
            img_extent = (gx[0], gx[-1], gy[0], gy[-1])
        ax.imshow(z, extent=img_extent, origin='lower', cmap=map_cmap, norm=norm, interpolation='nearest', zorder=1)
        if clev.size and np.ma.count(z) > 4:
            cs = ax.contour(gx, gy, z, levels=clev, colors=st.contour_color, linewidths=st.contour_width, alpha=st.contour_alpha, zorder=2)
            if cs.levels.size:
                ax.clabel(cs, fmt=st.contour_label_fmt, fontsize=st.contour_label_size, inline=True)
    ax.set_xlim(gx[0], gx[-1])
    ax.set_ylim(gy[0], gy[-1])
    cb_cmap = ListedColormap(_band_colors(st.colorbar_colors, st.n_bands))
    sm = ScalarMappable(norm=norm, cmap=cb_cmap)
    cbar = fig.colorbar(sm, cax=cax)
    cbar.outline.set_linewidth(st.cbar_outline_width)
    cbar.ax.tick_params(labelsize=st.tick_label_size)
    if st.render_mode == 'smooth':
        cbar.ax.yaxis.set_major_formatter(_tick_formatter(levels[0], levels[-1]))
    cbar.set_label(st.cbar_label, size=st.cbar_label_size)
    if settings_text:
        cax.text(0.0, -0.025, settings_text, transform=cax.transAxes, ha='left', va='top', fontsize=st.settings_size, color='#333333', linespacing=1.3)
    ax.set_title(title, fontsize=st.title_size)
    if attribution:
        txt = ax.text(0.005, 0.005, attribution, transform=ax.transAxes, size=st.attribution_size, ha='left', va='baseline', zorder=5, path_effects=[patheffects.withStroke(linewidth=st.attribution_stroke, foreground='w')])
        txt.set_clip_on(False)
    if st.projection_text:
        ax.text(0.99, 0.02, st.projection_text, transform=ax.transAxes, ha='right', va='bottom', fontsize=st.projection_size, zorder=5)
    save_kw = dict(dpi=st.dpi, bbox_inches='tight', pad_inches=st.pad_inches, facecolor='white')
    if layout is not None:
        renderer = fig.canvas.get_renderer()
        tight = fig.get_tightbbox(renderer)
        box = ax.get_window_extent(renderer)
        ox = (tight.x0 - st.pad_inches) * st.dpi
        oy = (tight.y1 + st.pad_inches) * st.dpi
        layout['mapBox'] = [round(box.x0 - ox, 1), round(oy - box.y1, 1), round(box.x1 - ox, 1), round(oy - box.y0, 1)]
        layout['extent'] = [float(gx[0]), float(gx[-1]), float(gy[0]), float(gy[-1])]
    try:
        if out_path is None:
            buf = io.BytesIO()
            fig.savefig(buf, format='png', **save_kw)
            return buf.getvalue()
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_path, **save_kw)
        return out_path
    finally:
        plt.close(fig)
