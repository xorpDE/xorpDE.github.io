from __future__ import annotations
import io
from dataclasses import dataclass
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import patheffects
from matplotlib.cm import ScalarMappable
from matplotlib.font_manager import FontProperties
from matplotlib.colors import BoundaryNorm, ListedColormap, LinearSegmentedColormap
from matplotlib.patches import PathPatch
from matplotlib.path import Path as MplPath
from matplotlib.text import Text
from matplotlib.ticker import FormatStrFormatter
from .geo import Extent, land_file, load_polygons, load_rings, rasterize_rings
from .style import MapStyle

@dataclass
class DistanceField:
    gx: np.ndarray
    gy: np.ndarray
    z: np.ma.MaskedArray
    extent: Extent
    vmin: float
    vmax: float

def _band_colors(colors: list[str], n: int) -> list:
    if n == len(colors):
        return list(colors)
    cmap = LinearSegmentedColormap.from_list('bands', colors)
    return [cmap(i / max(1, n - 1)) for i in range(n)]

def _signed_area(r: np.ndarray) -> float:
    x, y = (r[:, 0], r[:, 1])
    return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))

def land_path(extent: Extent, margin: float=0.05) -> MplPath:
    box = extent.buffered(margin)
    verts, codes = ([], [])
    for poly in load_polygons(land_file(extent)):
        ext = poly[0]
        if ext[:, 0].max() < box.xmin or ext[:, 0].min() > box.xmax or ext[:, 1].max() < box.ymin or (ext[:, 1].min() > box.ymax):
            continue
        for k, ring in enumerate(poly):
            area = _signed_area(ring)
            if k == 0 and area < 0 or (k > 0 and area > 0):
                ring = ring[::-1]
            verts.append(ring)
            verts.append(ring[:1])
            codes.extend([MplPath.MOVETO] + [MplPath.LINETO] * (len(ring) - 1) + [MplPath.CLOSEPOLY])
    if not verts:
        return MplPath(np.zeros((1, 2)))
    return MplPath(np.concatenate(verts), np.asarray(codes, dtype=MplPath.code_type))

def _tick_formatter(vmin: float, vmax: float) -> FormatStrFormatter:
    return FormatStrFormatter('%.5f')
_TICK_STEPS = {0.001: 3, 0.002: 3, 0.0025: 4, 0.005: 3, 0.01: 2, 0.02: 2, 0.025: 3, 0.05: 2, 0.1: 2, 0.2: 2, 0.25: 2, 0.5: 2, 1.0: 2}

def _round_ticks(vmin: float, vmax: float, most: int=6) -> tuple[list[float], str]:
    span = max(vmax - vmin, 1e-09)
    for step, decimals in _TICK_STEPS.items():
        if span / step <= most:
            break
    k0, k1 = (int(np.ceil(vmin / step - 1e-09)), int(np.floor(vmax / step + 1e-09)))
    ticks = [round(k * step, 6) for k in range(k0, k1 + 1)]
    if len(ticks) < 2:
        return ([vmin, vmax], '%.4f')
    return (ticks, f'%.{decimals}f')

def _draw_footer(fax, st: MapStyle, levels: np.ndarray, colors: list, width: float, height: float, settings_items: list | None, attribution: str | None) -> None:
    from matplotlib.patches import FancyBboxPatch
    fax.set_xlim(0, width)
    fax.set_ylim(0, height)
    fax.set_axis_off()
    head = dict(fontsize=7.2, color=st.footer_label_color, fontweight='bold', va='baseline')
    value = dict(fontsize=10, color=st.footer_text_color, fontweight='bold', va='baseline')
    fax.plot([0, width], [height - 0.01, height - 0.01], color=st.footer_rule_color, lw=0.6, solid_capstyle='butt')
    bar_h, gap = (0.17, 0.018)
    bar_y = height - 0.43
    head_y = bar_y + bar_h + 0.07
    hint_y = bar_y - 0.33
    renderer = fax.figure.canvas.get_renderer()
    to_inch = fax.transData.inverted()

    def text_w(t) -> float:
        bb = t.get_window_extent(renderer).transformed(to_inch)
        return bb.x1 - bb.x0
    pairs = [(fax.text(0, 0, label.upper(), ha='left', **head), fax.text(0, 0, val, ha='left', **value)) for label, val in settings_items or []]
    pair_gap, min_bar = (0.4, 1.8)

    def pair_w(h, v) -> float:
        return max(text_w(h), text_w(v))

    def scale(h, v, f) -> None:
        h.set_fontsize(head['fontsize'] * f)
        v.set_fontsize(value['fontsize'] * f)
    stacked = width < 5.2
    att_y = hint_y
    if stacked:
        bar_w = width
        y = hint_y - 0.24
        for h, v in pairs:
            if pair_w(h, v) > width:
                scale(h, v, max(0.5, width / pair_w(h, v)))
            h.set_position((0, y))
            v.set_position((0, y - 0.17))
            y -= 0.36
        att_y = y + 0.36 - 0.39
    else:
        room = width - 0.5 - min_bar
        gaps = pair_gap * max(0, len(pairs) - 1)
        content = sum((pair_w(h, v) for h, v in pairs))
        if pairs and content + gaps > room:
            for h, v in pairs:
                scale(h, v, max(0.6, (room - gaps) / content))
        bw = sum((pair_w(h, v) for h, v in pairs)) + gaps if pairs else 0.0
        bar_w = max(min_bar, min(width * st.footer_bar_frac, width - bw - 0.5))
        x = width - bw
        for h, v in pairs:
            h.set_position((x, head_y))
            v.set_position((x, bar_y + 0.02))
            x += pair_w(h, v) + pair_gap
    fax.text(0, head_y, 'GENETIC DISTANCE', ha='left', **head)
    n = len(colors)
    if st.footer_bar_style == 'segments':
        seg = (bar_w - gap * (n - 1)) / n
        for i, c in enumerate(colors):
            fax.add_patch(FancyBboxPatch((i * (seg + gap), bar_y), seg, bar_h, facecolor=c, edgecolor='none', boxstyle='round,pad=0,rounding_size=0.025', mutation_aspect=1))
    else:
        rgb = np.array([matplotlib.colors.to_rgb(c) for c in colors])
        if st.footer_bar_style == 'gradient':
            cm = LinearSegmentedColormap.from_list('scale', rgb)
            img, interp = (cm(np.linspace(0, 1, 512))[None, :, :3], 'bilinear')
        else:
            img, interp = (rgb[None, :, :], 'nearest')
        im = fax.imshow(img, extent=(0, bar_w, bar_y, bar_y + bar_h), aspect='auto', interpolation=interp, zorder=2)
        if st.footer_bar_style == 'flat':
            fax.add_patch(matplotlib.patches.Rectangle((0, bar_y), bar_w, bar_h, facecolor='none', edgecolor='#333333', lw=0.6, zorder=3))
        else:
            shape = FancyBboxPatch((0, bar_y), bar_w, bar_h, boxstyle=f'round,pad=0,rounding_size={bar_h / 2}', facecolor='none', edgecolor='none', transform=fax.transData)
            fax.add_patch(shape)
            im.set_clip_path(shape)
        fax.set_xlim(0, width)
        fax.set_ylim(0, height)
    vmin, vmax = (float(levels[0]), float(levels[-1]))
    ticks, fmt = _round_ticks(vmin, vmax, most=max(2, min(6, int(bar_w / 0.55))))
    for t in ticks:
        x = (t - vmin) / (vmax - vmin) * bar_w if vmax > vmin else bar_w
        fax.plot([x, x], [bar_y - 0.015, bar_y - 0.055], color='#555555', lw=0.6)
        label = fax.text(x, bar_y - 0.17, fmt % t, ha='center', fontsize=8.5, color=st.footer_text_color, va='baseline')
        half = text_w(label) / 2
        if x - half < 0:
            label.set_ha('left')
            label.set_x(0)
        elif x + half > width:
            label.set_ha('right')
            label.set_x(width)
    hint = dict(fontsize=7.2, color='#7a7a7a', va='baseline')
    fax.text(0, hint_y, '← closer', ha='left', **hint)
    farther = fax.text(bar_w, hint_y, 'farther →', ha='right', **hint)
    if attribution:
        att = fax.text(width, att_y, attribution, ha='right', va='baseline', fontsize=6.5, color='#8a8a8a')
        if not stacked and width - text_w(att) < bar_w + 0.15:
            att.set_y(bar_y - 0.17)

def _fit_title(ax, t, min_size: float=9.0) -> None:
    renderer = ax.figure.canvas.get_renderer()
    avail = ax.get_window_extent(renderer).width
    width = t.get_window_extent(renderer).width
    if width <= avail:
        return
    t.set_fontsize(max(min_size, t.get_fontsize() * avail / width * 0.98))
    text = t.get_text()
    while t.get_window_extent(renderer).width > avail and len(text) > 4:
        text = text[:-2].rstrip()
        t.set_text(text + '…')

def _luminance(color) -> float:
    lin = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in matplotlib.colors.to_rgb(color)]
    return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]

def _label_colors(level: float, st: MapStyle, band_levels, band_colors):
    dark, light = (st.contour_label_color, st.contour_label_light_color)
    if band_levels is None or band_colors is None or (not len(band_colors)):
        return (dark, None)
    n = len(band_colors)
    sides = [min(n - 1, max(0, int(np.searchsorted(band_levels, level + d, side='right')) - 1)) for d in (-1e-09, 1e-09)]
    ground = tuple((float(v) for v in np.mean([matplotlib.colors.to_rgb(band_colors[i]) for i in sides], axis=0)))
    if not light:
        return (dark, ground)
    bg = _luminance(ground)

    def contrast(c):
        a = _luminance(c)
        return (max(a, bg) + 0.05) / (min(a, bg) + 0.05)
    return (light if contrast(light) > contrast(dark) else dark, ground)

def _split_labelled(clev: np.ndarray, st: MapStyle) -> tuple[np.ndarray, np.ndarray]:
    clev = np.asarray(clev, dtype=float)
    if clev.size < 2 or st.contour_label_every <= 1:
        return (clev, clev[:0])
    step = float(np.min(np.diff(clev)))
    keep = np.array([round(v / step) % st.contour_label_every == 0 for v in clev])
    if not keep.any():
        return (clev, clev[:0])
    return (clev[keep], clev[~keep])

def _contour_lines(ax, gx, gy, z, clev, st: MapStyle, clip=None, band_levels=None, band_colors=None, ground=None) -> None:
    labelled, plain = _split_labelled(clev, st)
    for levs, with_labels in ((plain, False), (labelled, True)):
        if not levs.size:
            continue
        cs = ax.contour(gx, gy, z, levels=levs, colors=st.contour_color, linewidths=st.contour_width, alpha=st.contour_alpha, zorder=2)
        if clip is not None:
            cs.set_clip_path(clip)
        if with_labels:
            _label_contours(ax, cs, st, band_levels, band_colors, ground)

class _Ground:

    def __init__(self, gx, gy, land: np.ndarray, values: np.ndarray, band_levels, band_colors, sea_color, extent: Extent | None=None):
        self.x0, self.y0 = (float(gx[0]), float(gy[0]))
        self.cell = (float(gx[1] - gx[0]), float(gy[1] - gy[0]))
        self.land = land
        self.values = values
        self.band_levels = np.asarray(band_levels, dtype=float)
        self.band_lum = np.array([_luminance(c) for c in band_colors])
        self.sea_lum = _luminance(sea_color)
        self._gx, self._gy, self._extent = (np.asarray(gx, dtype=float), np.asarray(gy, dtype=float), extent)
        self._fine = None
    FINE = 4

    def on_land_exact(self, x, y):
        if self._extent is None:
            return self.on_land(x, y)
        if self._fine is None:
            f = self.FINE
            fx = np.linspace(self._gx[0], self._gx[-1], (len(self._gx) - 1) * f + 1)
            fy = np.linspace(self._gy[0], self._gy[-1], (len(self._gy) - 1) * f + 1)
            self._fine = (rasterize_rings(load_rings(land_file(self._extent)), fx, fy), fx[1] - fx[0], fy[1] - fy[0])
        mask, dx, dy = self._fine
        ny, nx = mask.shape
        j = np.rint((np.asarray(x, dtype=float) - self.x0) / dx).astype(int)
        i = np.rint((np.asarray(y, dtype=float) - self.y0) / dy).astype(int)
        inside = (i >= 0) & (i < ny) & (j >= 0) & (j < nx)
        out = np.zeros(i.shape, dtype=bool)
        out[inside] = mask[i[inside], j[inside]]
        return out

    def _cells(self, x, y):
        ny, nx = self.land.shape
        j = np.rint((np.asarray(x, dtype=float) - self.x0) / self.cell[0]).astype(int)
        i = np.rint((np.asarray(y, dtype=float) - self.y0) / self.cell[1]).astype(int)
        inside = (i >= 0) & (i < ny) & (j >= 0) & (j < nx)
        return (i, j, inside)

    def on_land(self, x, y):
        i, j, inside = self._cells(x, y)
        out = np.zeros(i.shape, dtype=bool)
        out[inside] = self.land[i[inside], j[inside]]
        return out

    def luminance(self, x, y):
        i, j, inside = self._cells(x, y)
        on = np.zeros(i.shape, dtype=bool)
        on[inside] = self.land[i[inside], j[inside]]
        out = np.full(i.shape, self.sea_lum, dtype=float)
        k = np.clip(np.searchsorted(self.band_levels, self.values[i[on], j[on]], side='right') - 1, 0, len(self.band_lum) - 1)
        out[on] = self.band_lum[k]
        return out

def _components(path):
    if hasattr(path, '_iter_connected_components'):
        for sub in path._iter_connected_components():
            codes = sub.codes
            yield (sub.vertices, bool(codes is not None and len(codes) and (codes[-1] == MplPath.CLOSEPOLY)))
        return
    codes = path.codes
    if codes is None:
        yield (path.vertices, False)
        return
    starts = list(np.flatnonzero(codes == MplPath.MOVETO)) + [len(codes)]
    for a, b in zip(starts[:-1], starts[1:]):
        if b > a:
            yield (path.vertices[a:b], bool(codes[b - 1] == MplPath.CLOSEPOLY))

def _label_angle(xy: np.ndarray, k: int, w: float, closed: bool) -> float:
    if closed:
        xy = np.concatenate([xy[k:-1], xy[:k + 1]])
        k = 0
    cpl = np.insert(np.cumsum(np.hypot(*np.diff(xy, axis=0).T)), 0, 0)
    cpl -= cpl[k]
    t = np.array([-w / 2, w / 2])
    if closed:
        t[0] += cpl[-1] - cpl[0]
    x0, x1 = np.interp(t, cpl, xy[:, 0])
    y0, y1 = np.interp(t, cpl, xy[:, 1])
    return float((np.rad2deg(np.arctan2(y1 - y0, x1 - x0)) + 90) % 180 - 90)

def _box(x, y, a, half_w, below, above):
    ca, sa = (np.cos(a), np.sin(a))
    return np.array([(x + u * ca - v * sa, y + u * sa + v * ca) for u, v in ((-half_w, -below), (half_w, -below), (half_w, above), (-half_w, above))])

def _boxes_overlap(p, q) -> bool:
    for poly in (p, q):
        for i in range(4):
            e = poly[(i + 1) % 4] - poly[i]
            n = np.array([-e[1], e[0]])
            a, b = (p @ n, q @ n)
            if a.max() < b.min() or b.max() < a.min():
                return False
    return True

def _label_spots(ax, cs, st: MapStyle, ground) -> list:
    fig = ax.figure
    renderer = fig.canvas.get_renderer()
    trans, to_data = (cs.get_transform(), ax.transData.inverted())
    props = FontProperties(size=st.contour_label_size)
    em = st.contour_label_size * fig.dpi / 72.0
    below, above = (0.32 * em, 0.56 * em)
    margin = 0.06 * em
    (xa, xb), (ya, yb) = (sorted(ax.get_xlim()), sorted(ax.get_ylim()))
    inks = [(st.contour_label_color, _luminance(st.contour_label_color))]
    if st.contour_label_light_color:
        inks.append((st.contour_label_light_color, _luminance(st.contour_label_light_color)))
    light = st.contour_label_light_color
    placed, boxes, spots = ([], [], [])
    labelled, waiting = (set(), {})
    for li, (lev, path) in enumerate(zip(cs.levels, cs.get_paths())):
        w = Text(0, 0, st.contour_label_fmt % lev, figure=fig, fontproperties=props).get_window_extent(renderer).width
        u, v = np.meshgrid(np.linspace(-w / 2 - margin, w / 2 + margin, 25), np.linspace(-below - margin, above + margin, 9))
        ul, vl = np.meshgrid(np.linspace(-w / 2 - margin, w / 2 + margin, 49), np.linspace(-below - margin, above + margin, 17))
        for verts, closed in _components(path):
            xy = trans.transform(verts)
            n = len(xy)
            if not (n > 10 * w or (n and (np.ptp(xy, axis=0) > 1.2 * w).any())):
                continue
            n_blocks = int(np.ceil(n / w)) if w > 1 else 1
            block = n if n_blocks == 1 else int(w)
            xx = np.resize(xy[:, 0], (n_blocks, block))
            yy = np.resize(xy[:, 1], (n_blocks, block))
            s_ = (yy[:, :1] - yy) * (xx[:, -1:] - xx[:, :1]) - (xx[:, :1] - xx) * (yy[:, -1:] - yy[:, :1])
            with np.errstate(divide='ignore', invalid='ignore'):
                bend = (np.abs(s_) / np.hypot(xx[:, -1:] - xx[:, :1], yy[:, -1:] - yy[:, :1])).sum(axis=-1)
            cpl = np.insert(np.cumsum(np.hypot(*np.diff(xy, axis=0).T)), 0, 0)
            for b in np.argsort(bend):
                k = int((b * block + block // 2) % n)
                x, y = xy[k]
                if not closed and min(cpl[k], cpl[-1] - cpl[k]) < w / 2 + 5:
                    continue
                a = np.deg2rad(_label_angle(xy, k, w, closed))
                ca, sa = (np.cos(a), np.sin(a))
                d = to_data.transform(np.column_stack([(x + u * ca - v * sa).ravel(), (y + u * sa + v * ca).ravel()]))
                if not ((d[:, 0] >= xa) & (d[:, 0] <= xb) & (d[:, 1] >= ya) & (d[:, 1] <= yb)).all():
                    continue
                under = ground.luminance(d[:, 0], d[:, 1])
                scored = []
                for ink, lum in inks:
                    c = (np.maximum(lum, under) + 0.05) / (np.minimum(lum, under) + 0.05)
                    scored.append((float(np.percentile(c, 10)), ink))
                chosen = None
                for score, ink in sorted(scored, reverse=True):
                    if score < st.contour_label_min_contrast:
                        break
                    if light and ink == light:
                        dl = to_data.transform(np.column_stack([(x + ul * ca - vl * sa).ravel(), (y + ul * sa + vl * ca).ravel()]))
                        if not ground.on_land_exact(dl[:, 0], dl[:, 1]).all():
                            continue
                    chosen = ink
                    break
                if chosen is None:
                    continue
                pad = 0.2 * em
                box = _box(x, y, a, w / 2 + pad, below + pad, above + pad)
                if any(((x - px) ** 2 + (y - py) ** 2 < (1.2 * w) ** 2 for px, py in placed)):
                    waiting.setdefault(li, []).append((x, y, chosen, box))
                    continue
                placed.append((x, y))
                boxes.append(box)
                spots.append((tuple(to_data.transform((x, y))), chosen))
                labelled.add(li)
                break
    for li in sorted(waiting):
        if li in labelled:
            continue
        for x, y, ink, box in waiting[li]:
            if any((_boxes_overlap(box, other) for other in boxes)):
                continue
            placed.append((x, y))
            boxes.append(box)
            spots.append((tuple(to_data.transform((x, y))), ink))
            labelled.add(li)
            break
    return spots

def _label_contours(ax, cs, st: MapStyle, band_levels=None, band_colors=None, ground=None) -> None:
    if not len(cs.levels):
        return
    font = {'font.family': [st.contour_label_font]} if st.contour_label_font else {}
    inks = None
    with plt.rc_context(font):
        kw = dict(fmt=st.contour_label_fmt, fontsize=st.contour_label_size, inline=True, colors=st.contour_label_color)
        if ground is not None and st.contour_label_on_land:
            spots = _label_spots(ax, cs, st, ground)
            texts = ax.clabel(cs, manual=[p for p, _ in spots], **kw) if spots else []
            inks = [ink for _, ink in spots]
        else:
            texts = ax.clabel(cs, **kw)
    for i, t in enumerate(texts):
        t.set_alpha(1.0)
        try:
            level = float(t.get_text())
        except ValueError:
            level = None
        ink, ground_rgb = _label_colors(level, st, band_levels, band_colors) if level is not None else (None, None)
        if inks is not None and i < len(inks):
            ink = inks[i]
        if ink is not None:
            t.set_color(ink)
        if st.contour_label_halo > 0:
            t.set_path_effects([patheffects.withStroke(linewidth=st.contour_label_halo, foreground='white')])
        elif st.contour_label_ground > 0 and ground_rgb is not None:
            t.set_path_effects([patheffects.withStroke(linewidth=st.contour_label_ground, foreground=ground_rgb)])

def map_box_inches(extent: Extent, st: MapStyle) -> tuple[float, float]:
    default = st.map_width_in / st.map_height_in
    a = extent.aspect
    if abs(a - default) < 0.001:
        return (st.map_width_in, st.map_height_in)
    if a > default:
        return (st.map_width_in, st.map_width_in / a)
    return (st.map_height_in * a, st.map_height_in)

def band_levels(vmin: float, vmax: float, n_bands: int) -> np.ndarray:
    if not np.isfinite(vmin) or vmin >= vmax:
        vmin = 0.0 if vmax > 0 else vmax - 0.001
    return np.linspace(vmin, vmax, n_bands + 1)

def contour_levels(vmin: float, vmax: float, step: float, max_lines: int=15) -> np.ndarray:
    for s in [step] + [c for c in (0.02, 0.05, 0.1) if c > step]:
        k0 = int(np.floor(vmin / s)) + 1
        k1 = int(np.ceil(vmax / s)) - 1
        if k1 - k0 + 1 <= max_lines:
            break
    if k1 < k0:
        return np.array([])
    return np.round(np.arange(k0, k1 + 1) * s, 10)
_FONT_DIRS = (Path(__file__).parent / 'data', Path(__file__).parent)
_fonts_registered = False

def _register_fonts() -> None:
    global _fonts_registered
    if _fonts_registered:
        return
    from matplotlib import font_manager
    for folder in _FONT_DIRS:
        for f in sorted(folder.glob('*.ttf')) if folder.is_dir() else []:
            font_manager.fontManager.addfont(str(f))
    _fonts_registered = True

def render_map(field: DistanceField, title: str, out_path: str | Path | None=None, style: MapStyle | None=None, **kwargs):
    st = style or MapStyle()
    _register_fonts()
    with plt.rc_context({'font.family': [st.font_family, 'DejaVu Sans']}):
        return _render_map(field, title, out_path, st, **kwargs)

def _render_map(field: DistanceField, title: str, out_path: str | Path | None=None, style: MapStyle | None=None, background=None, attribution: str | None=None, layout: dict | None=None, settings_text: str | None=None, subtitle: str | None=None, settings_items: list | None=None, brand: str | None=None):
    st = style or MapStyle()
    ext = field.extent
    gx, gy = (field.gx, field.gy)
    map_w, map_h = map_box_inches(ext, st)
    scale = max(0.55, map_h / (2209 / 300))
    horizontal = st.cbar_orientation == 'horizontal'
    footer = st.cbar_orientation == 'footer'
    if footer:
        footer_h = st.footer_height_in + (0.25 + 0.36 * len(settings_items or []) if map_w < 5.2 else 0.0)
        left_m, right_m, bottom_m, top_m = (0.3, 0.3, 0.25, 0.9)
        fig_w = left_m + map_w + right_m
        fig_h = bottom_m + footer_h + st.footer_gap_in + map_h + top_m
        map_y = bottom_m + footer_h + st.footer_gap_in
        fig = plt.figure(figsize=(fig_w, fig_h), dpi=st.dpi)
        ax = fig.add_axes([left_m / fig_w, map_y / fig_h, map_w / fig_w, map_h / fig_h])
        cax = fig.add_axes([left_m / fig_w, bottom_m / fig_h, map_w / fig_w, footer_h / fig_h])
    elif horizontal:
        cbar_w, cbar_h = (map_w * st.hbar_width_frac, st.hbar_height_in)
        left_m, right_m, bottom_m, top_m = (0.3, 0.3, 0.75, 0.9)
        fig_w = left_m + map_w + right_m
        fig_h = bottom_m + cbar_h + st.hbar_gap_in + map_h + top_m
        map_y = bottom_m + cbar_h + st.hbar_gap_in
        fig = plt.figure(figsize=(fig_w, fig_h), dpi=st.dpi)
        ax = fig.add_axes([left_m / fig_w, map_y / fig_h, map_w / fig_w, map_h / fig_h])
        cax = fig.add_axes([left_m / fig_w, bottom_m / fig_h, cbar_w / fig_w, cbar_h / fig_h])
    else:
        cbar_h = st.cbar_height_in * scale
        cbar_w = st.cbar_width_in * scale
        left_m, right_m, bottom_m, top_m = (0.3, 1.6, 0.3, 0.8)
        fig_w = left_m + map_w + st.cbar_gap_in + cbar_w + right_m
        fig_h = bottom_m + map_h + top_m
        fig = plt.figure(figsize=(fig_w, fig_h), dpi=st.dpi)
        ax = fig.add_axes([left_m / fig_w, bottom_m / fig_h, map_w / fig_w, map_h / fig_h])
        cbar_y = bottom_m + (map_h - cbar_h if st.cbar_valign == 'top' else (map_h - cbar_h) / 2)
        cax = fig.add_axes([(left_m + map_w + st.cbar_gap_in) / fig_w, cbar_y / fig_h, cbar_w / fig_w, cbar_h / fig_h])
    ax.set_xlim(gx[0], gx[-1])
    ax.set_ylim(gy[0], gy[-1])
    ax.set_aspect('auto')
    ax.set_axis_off()
    if background is not None:
        ax.imshow(background, extent=(gx[0], gx[-1], gy[0], gy[-1]), origin='upper', interpolation='bilinear', zorder=0)
    else:
        ax.imshow(np.array([[matplotlib.colors.to_rgb(st.sea_color)]]), extent=(gx[0], gx[-1], gy[0], gy[-1]), origin='upper', zorder=0)
    levels = band_levels(field.vmin, field.vmax, st.n_bands)
    norm = BoundaryNorm(levels, ncolors=st.n_bands)
    map_cmap = ListedColormap(_band_colors(st.map_colors, st.n_bands)).with_extremes(bad=(0, 0, 0, 0))
    z = np.ma.clip(field.z, levels[0], levels[-1])
    clev = contour_levels(field.vmin, field.vmax, st.contour_step)
    band_colors = _band_colors(st.map_colors, st.n_bands)
    ground = _Ground(gx, gy, ~np.ma.getmaskarray(field.z), np.clip(np.ma.getdata(field.z).astype(float), levels[0], levels[-1]), levels, band_colors, st.sea_color, ext)
    if st.render_mode == 'smooth':
        clip = PathPatch(land_path(ext), transform=ax.transData, facecolor='none', edgecolor='none')
        zfull = np.clip(np.ma.getdata(field.z).astype(float), levels[0], levels[-1])
        cf = ax.contourf(gx, gy, zfull, levels=levels, colors=band_colors, antialiased=True, zorder=1)
        cf.set_edgecolor('face')
        cf.set_linewidth(0.3)
        cf.set_clip_path(clip)
        if clev.size and np.ma.count(z) > 4:
            from scipy.ndimage import binary_dilation
            near_land = binary_dilation(~np.ma.getmaskarray(field.z), iterations=1)
            _contour_lines(ax, gx, gy, np.ma.masked_array(zfull, ~near_land), clev, st, clip, levels, band_colors, ground)
    else:
        dx = gx[1] - gx[0]
        dy = gy[1] - gy[0]
        if st.raster_mode == 'centered':
            img_extent = (gx[0] - dx / 2, gx[-1] + dx / 2, gy[0] - dy / 2, gy[-1] + dy / 2)
        else:
            img_extent = (gx[0], gx[-1], gy[0], gy[-1])
        ax.imshow(z, extent=img_extent, origin='lower', cmap=map_cmap, norm=norm, interpolation='nearest', zorder=1)
        if clev.size and np.ma.count(z) > 4:
            _contour_lines(ax, gx, gy, z, clev, st, None, levels, band_colors, ground)
    if st.coast_width > 0:
        ax.add_patch(PathPatch(land_path(ext), transform=ax.transData, facecolor='none', edgecolor=st.coast_color, linewidth=st.coast_width, alpha=st.coast_alpha, zorder=3))
    ax.set_xlim(gx[0], gx[-1])
    ax.set_ylim(gy[0], gy[-1])
    if footer:
        _draw_footer(cax, st, levels, _band_colors(st.colorbar_colors, st.n_bands), map_w, footer_h, settings_items, attribution)
    else:
        cb_cmap = ListedColormap(_band_colors(st.colorbar_colors, st.n_bands))
        sm = ScalarMappable(norm=norm, cmap=cb_cmap)
        cbar = fig.colorbar(sm, cax=cax, orientation='horizontal' if horizontal else 'vertical')
        cbar.outline.set_linewidth(st.cbar_outline_width)
        cbar.ax.tick_params(labelsize=st.tick_label_size)
        axis = cbar.ax.xaxis if horizontal else cbar.ax.yaxis
        if st.cbar_ticks == 'round':
            ticks, fmt = _round_ticks(levels[0], levels[-1])
            cbar.set_ticks(ticks)
            axis.set_major_formatter(FormatStrFormatter(fmt))
            cbar.minorticks_off()
        elif st.render_mode == 'smooth':
            axis.set_major_formatter(_tick_formatter(levels[0], levels[-1]))
        cbar.set_label(st.cbar_label, size=st.cbar_label_size)
    if settings_text and (not footer):
        if horizontal:
            cax.text(1.0 + 0.3 / cbar_w, 1.0, settings_text, transform=cax.transAxes, ha='left', va='top', fontsize=st.settings_size, color='#333333', linespacing=1.3)
        else:
            cax.text(0.0, -0.025, settings_text, transform=cax.transAxes, ha='left', va='top', fontsize=st.settings_size, color='#333333', linespacing=1.3)
    if st.title_layout == 'headline' and subtitle:
        t = ax.set_title(title, loc='left', fontsize=st.title_size, fontweight=st.title_weight, pad=st.subtitle_size * 1.3 + 6, parse_math=False)
        sub = ax.annotate(subtitle, xy=(0, 1), xycoords='axes fraction', xytext=(0, 5), textcoords='offset points', ha='left', va='bottom', fontsize=st.subtitle_size, color=st.subtitle_color, parse_math=False)
        if brand:
            br = ax.annotate(brand, xy=(1, 1), xycoords='axes fraction', xytext=(0, 5), textcoords='offset points', ha='right', va='bottom', fontsize=st.subtitle_size, color=st.subtitle_color, parse_math=False)
            renderer = fig.canvas.get_renderer()
            avail, gap_px = (ax.get_window_extent(renderer).width, 0.15 * fig.dpi)
            both = lambda: sub.get_window_extent(renderer).width + br.get_window_extent(renderer).width + gap_px
            if both() > avail:
                f = max(6.5 / st.subtitle_size, (avail - gap_px) / (both() - gap_px))
                sub.set_fontsize(st.subtitle_size * f)
                br.set_fontsize(st.subtitle_size * f)
                if both() > avail:
                    sub.set_visible(False)
    else:
        t = ax.set_title(title, fontsize=st.title_size, fontweight=st.title_weight, loc='left' if st.title_layout == 'headline' else 'center', parse_math=False)
    _fit_title(ax, t)
    if attribution and (not footer):
        txt = ax.text(0.005, 0.005, attribution, transform=ax.transAxes, size=st.attribution_size, ha='left', va='baseline', zorder=5, path_effects=[patheffects.withStroke(linewidth=st.attribution_stroke, foreground='w')])
        txt.set_clip_on(False)
    if st.projection_text:
        ax.text(0.99, 0.02, st.projection_text, transform=ax.transAxes, ha='right', va='bottom', fontsize=st.projection_size, zorder=5)
    save_kw = dict(dpi=st.dpi, bbox_inches='tight', pad_inches=st.pad_inches, facecolor='white')
    if layout is not None:
        renderer = fig.canvas.get_renderer()
        tight = fig.get_tightbbox(renderer)
        box = ax.get_window_extent(renderer)
        ox = (tight.x0 - st.pad_inches) * st.dpi
        oy = (tight.y0 - st.pad_inches) * st.dpi + int((tight.height + 2 * st.pad_inches) * st.dpi)
        layout['mapBox'] = [round(box.x0 - ox, 1), round(oy - box.y1, 1), round(box.x1 - ox, 1), round(oy - box.y0, 1)]
        layout['extent'] = [float(gx[0]), float(gx[-1]), float(gy[0]), float(gy[-1])]
    try:
        if out_path is None:
            buf = io.BytesIO()
            fig.savefig(buf, format='png', **save_kw)
            return buf.getvalue()
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out_path, **save_kw)
        return out_path
    finally:
        plt.close(fig)
